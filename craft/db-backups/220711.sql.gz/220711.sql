-- MySQL dump 10.13  Distrib 8.0.26, for Linux (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.26-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `ownerId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_jpgahqfepnufeikiwwpgvkkzumnounmsvurd` (`ownerId`),
  CONSTRAINT `fk_fbsvcmjfbmdryhuoysdruvhtubyhsccsalep` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jpgahqfepnufeikiwwpgvkkzumnounmsvurd` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rbiwjmhlyqisjlvjtanxtssjkktkdngzzhff` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_tvbshtgaxwzbqbcqmmryjjvvpazdlklbzoth` (`dateRead`),
  KEY `fk_wyxotartflkzhyljnttflrpysqhnswzzlzbg` (`pluginId`),
  CONSTRAINT `fk_ttsersrfjlpkzoccsopjwtxiskzttwgvdvxt` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wyxotartflkzhyljnttflrpysqhnswzzlzbg` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mdcwgaswffzozsmeyloocijeolqllecfwbzj` (`sessionId`,`volumeId`),
  KEY `idx_nysdiyrlzebrukzmeaowtbivmzxorpaoyjnu` (`volumeId`),
  CONSTRAINT `fk_gusfccdmnppfqlhggbgoibrrazalovbtybck` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lnmsfizrgdoycdqrjkzebmiusjhbohgttbpy` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_sgfetuitjkpjdejyeztxhfvhhawaexzetaty` (`filename`,`folderId`),
  KEY `idx_thurevnfxaaylqxccsudgffvkjnysolvgrsh` (`folderId`),
  KEY `idx_jdfuzshygdatzmcdybpdzayimycgnusxkoup` (`volumeId`),
  KEY `fk_dqzevmhubgsrkyfbwlbwvuluojeljwatdxvt` (`uploaderId`),
  CONSTRAINT `fk_dqzevmhubgsrkyfbwlbwvuluojeljwatdxvt` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wdzezvryuzmggwnncvfbvxxpunhrlvpetzhs` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xlbvuwiifylzwhahmhzrwpjeplxmnnwgttpb` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ynlitnfppbnmiezlyxaagodlodenleqonkgd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lfbxkicajiixqbhncjhjazjypsfrgaakcowx` (`groupId`),
  KEY `fk_sygjdetitkfvjtznkalvgpjcuyziljdnrjpb` (`parentId`),
  CONSTRAINT `fk_sygjdetitkfvjtznkalvgpjcuyziljdnrjpb` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_vpkhuvnubmslvjmcwxuqlqqlzrmgwfzxgjyc` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yanacpzfwdnusgbvskwcyqclmmplmrcjncun` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bquckscgwhpskcbnnqiqlubjkrzzgkfmcycs` (`name`),
  KEY `idx_iubzklgcubwiigxqlyceincjwbxcjhzkwrvu` (`handle`),
  KEY `idx_zythbbqyyddjlzovbqwqulzhweuirstcvjie` (`structureId`),
  KEY `idx_hmcgogsjomckxzqzmhqbockqnwhbyfhlsdvm` (`fieldLayoutId`),
  KEY `idx_jeldbfgrcscqlqmhvgcntntiyehpdrsmmoxo` (`dateDeleted`),
  CONSTRAINT `fk_imziidzoibutbgyjdqhlbkzmvolbcflcsjdd` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_kwzeylkfgrqaobqkytfgofovvuvummadkwai` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_gzrdneunovjvwjojfjivimiofvwhrotktiss` (`groupId`,`siteId`),
  KEY `idx_dhuixuawggvohwivhsdkmifevdlmirvtwmqp` (`siteId`),
  CONSTRAINT `fk_aqwlfhhwesxwrdfawhzeuqvrnmytlipoajqe` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_hrosiyhaclhrznushsuymgbdxocgupcqizxt` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_dbnwidnubqypisdctjsmopirzxvlzodfxrsx` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_pwszxdbegirgqztdcdyrziexfkqrnvgmnkeb` (`siteId`),
  KEY `fk_xwnkptdgjonxfxogyyveqcascivifzucuzxz` (`userId`),
  CONSTRAINT `fk_pwszxdbegirgqztdcdyrziexfkqrnvgmnkeb` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tbfzosahpggnzoxwlupvonawwubfyimjsppr` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_xwnkptdgjonxfxogyyveqcascivifzucuzxz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
INSERT INTO `changedattributes` VALUES (2,1,'authorId','2022-07-11 12:46:59',0,1),(2,1,'postDate','2022-07-11 12:43:18',0,1),(2,1,'slug','2022-07-11 12:43:14',0,1),(2,1,'title','2022-07-11 12:43:14',0,1),(2,1,'uri','2022-07-11 12:46:59',0,1),(11,1,'slug','2022-07-11 13:45:33',0,1),(17,1,'slug','2022-07-11 13:44:17',0,1),(20,1,'slug','2022-07-11 13:44:07',0,1),(20,1,'uri','2022-07-11 13:59:00',0,1),(24,1,'slug','2022-07-11 13:43:44',0,1),(28,1,'slug','2022-07-11 13:44:26',0,1),(31,1,'uri','2022-07-11 13:59:18',0,1),(34,1,'slug','2022-07-11 13:45:16',0,1);
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_dzculxythwwxsonmkpedmejyvxwmyjtjodsm` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_zluoazggirhfylqkochvyxtwcvcituvejjiw` (`siteId`),
  KEY `fk_ssezukggwzictxxcxsvmmsbotufkalquoocd` (`fieldId`),
  KEY `fk_aouhgclhrmngipfirzsjnfiyhqikiytrlfmd` (`userId`),
  CONSTRAINT `fk_aouhgclhrmngipfirzsjnfiyhqikiytrlfmd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_ssezukggwzictxxcxsvmmsbotufkalquoocd` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tvbdzfhzttoxpdyrhazfunrftnorylmmfmpy` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_zluoazggirhfylqkochvyxtwcvcituvejjiw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `content` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cthngvrsujdokvfdxdlhkefgoiujscdjuxse` (`elementId`,`siteId`),
  KEY `idx_gmnbskxxsvhwozesgqexrivrpwzmozuavesx` (`siteId`),
  KEY `idx_hjbesyajvasjkrrrbfthudbgbjznqkvkotor` (`title`),
  CONSTRAINT `fk_puluboeromvuwzepoqszibtcqhsdwworidbn` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qivasvshzfqlobkxmziobbbekamaxeqvdbai` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (1,1,1,NULL,'2022-06-25 16:51:30','2022-06-25 16:51:30','2d459210-ec5e-4e8e-bd2b-984c43e28b59'),(2,2,1,'Start','2022-07-11 12:43:10','2022-07-11 14:12:10','ace5fb64-07a4-459b-8206-4965c7682c5f'),(3,3,1,'Start','2022-07-11 12:43:18','2022-07-11 12:43:18','899e0432-4f31-434e-acb7-b367536d9867'),(4,4,1,'Start','2022-07-11 12:46:59','2022-07-11 12:46:59','9d65931a-bd80-4a37-b243-1cce56f11cd1'),(5,5,1,'Start','2022-07-11 12:46:59','2022-07-11 12:46:59','938bcbf6-ce40-4f9f-959c-cc350092ade1'),(6,6,1,'Start','2022-07-11 12:46:59','2022-07-11 12:46:59','aa19b870-f1b9-4415-9565-6f872bac3a99'),(7,7,1,'Start','2022-07-11 12:49:29','2022-07-11 12:49:29','9dc69a13-775b-4ac8-af80-a2f4b4e5a649'),(8,8,1,'Start','2022-07-11 12:49:29','2022-07-11 12:49:29','5f5d41ad-e2e5-42fc-af63-98cd07b8b3b7'),(9,9,1,'Start','2022-07-11 13:00:48','2022-07-11 13:00:48','8fe021d2-5940-42db-a794-66f66891998b'),(10,10,1,'Start','2022-07-11 13:00:48','2022-07-11 13:00:48','9bba35af-2c64-41f6-8683-552834ec31b6'),(11,11,1,'Investment Advisory','2022-07-11 13:25:41','2022-07-11 14:07:16','72dd8806-8b74-485a-b3f3-2a60163ce9a0'),(12,12,1,'Investment Advisory','2022-07-11 13:25:41','2022-07-11 13:25:41','810c2add-357e-42e1-a4e5-ea577c9373dc'),(13,13,1,'Investment Advisory','2022-07-11 13:25:41','2022-07-11 13:25:41','c5b304cb-4d32-4f40-aee0-046225ede3c3'),(14,14,1,'Investment Advisory','2022-07-11 13:25:42','2022-07-11 13:25:42','8554eefd-8241-449d-bf53-8bc6fe8c3052'),(15,15,1,'Investment Advisory','2022-07-11 13:25:48','2022-07-11 13:25:48','6cae9a9c-52d4-4c6d-beb4-f456e50f6a17'),(16,16,1,'Investment Advisory','2022-07-11 13:27:10','2022-07-11 13:27:10','257b77ec-d104-4a63-ac97-3f44af852009'),(17,17,1,'Data Privacy','2022-07-11 13:40:11','2022-07-11 13:44:17','565b84bd-b8cf-436c-a0f2-959dc5b60588'),(18,18,1,'Data Privacy','2022-07-11 13:40:11','2022-07-11 13:40:11','2c5cacab-62f4-4027-bf81-5539c799d589'),(19,19,1,'Data Privacy','2022-07-11 13:40:11','2022-07-11 13:40:11','f79ea653-c8b4-4ad8-94c8-e7be948bd195'),(20,20,1,'Contact','2022-07-11 13:40:40','2022-07-11 13:59:01','dcbbc017-f7e6-42d0-b89f-c45e2be71094'),(21,21,1,'Contact','2022-07-11 13:40:40','2022-07-11 13:40:40','82aa1cfb-c5b3-4b8d-ac1a-bad34f43a769'),(22,22,1,'Contact','2022-07-11 13:40:40','2022-07-11 13:40:40','0ad36815-b1c5-45d2-ae97-bf3771b5b35c'),(23,23,1,'Contact','2022-07-11 13:40:40','2022-07-11 13:40:40','b384080f-0902-4b7b-909b-d39dd9943bac'),(24,24,1,'About Us','2022-07-11 13:40:50','2022-07-11 13:43:44','237edace-f223-41d3-bcf6-682b8834dbea'),(25,25,1,'About Us','2022-07-11 13:40:50','2022-07-11 13:40:50','cba0c8cb-50d7-47bc-a64c-ed6368772ad3'),(26,26,1,'About Us','2022-07-11 13:40:50','2022-07-11 13:40:50','6de5874a-7bc4-48e3-ac84-d01696b7a3cc'),(27,27,1,'About Us','2022-07-11 13:40:51','2022-07-11 13:40:51','f55fb14a-a98a-424c-92f1-fee63debbdb0'),(28,28,1,'Imprint','2022-07-11 13:41:23','2022-07-11 13:44:26','59f48abd-0f19-4742-bfef-c327810c58f3'),(29,29,1,'Imprint','2022-07-11 13:41:23','2022-07-11 13:41:23','4f357c00-761a-4362-a136-c3ba683affa5'),(30,30,1,'Imprint','2022-07-11 13:41:23','2022-07-11 13:41:23','e5c2fb05-d768-40a4-b7d4-678458fd82c3'),(31,31,1,'Login','2022-07-11 13:42:31','2022-07-11 13:59:19','b8ba427c-0bc9-46ac-bc8f-a9774cf11522'),(32,32,1,'Login','2022-07-11 13:42:31','2022-07-11 13:42:31','087cfb55-522e-4435-a38d-9e9ecb720c07'),(33,33,1,'Login','2022-07-11 13:42:31','2022-07-11 13:42:31','31d7cfd2-6904-440f-98e1-d2e9f155888b'),(34,34,1,'Retirement Solutions','2022-07-11 13:43:06','2022-07-11 13:45:16','5430e30e-0e3b-41b1-995c-35f32c88c7e3'),(35,35,1,'Retirement Solutions','2022-07-11 13:43:06','2022-07-11 13:43:06','d982ef2e-4340-4a6c-93b5-37e87a294e1a'),(36,36,1,'Retirement Solutions','2022-07-11 13:43:06','2022-07-11 13:43:06','578d5813-865f-47e1-9531-5429eb079000'),(38,38,1,'Retirement Solutions','2022-07-11 13:43:36','2022-07-11 13:43:36','f30f57d9-be8f-43fe-a950-1874f4af1675'),(40,40,1,'About Us','2022-07-11 13:43:44','2022-07-11 13:43:44','d89cc5d6-f430-477e-bbd3-fb5136f91817'),(42,42,1,'Contact','2022-07-11 13:44:07','2022-07-11 13:44:07','068c10c3-2115-4d74-b1b3-41ff90162ee1'),(44,44,1,'Data Privacy','2022-07-11 13:44:17','2022-07-11 13:44:17','6887e5f9-5126-4108-83b5-90b03adf46c9'),(46,46,1,'Imprint','2022-07-11 13:44:26','2022-07-11 13:44:26','d389311a-201e-4988-83cc-dc71388843ca'),(48,48,1,'Retirement Solutions','2022-07-11 13:45:16','2022-07-11 13:45:16','8fe237d3-316c-43da-bd5b-3689622f65d1'),(50,50,1,'Investment Advisory','2022-07-11 13:45:33','2022-07-11 13:45:33','c78bcdd6-9eb4-455f-9825-a2480c63e4a0'),(51,51,1,'Contact','2022-07-11 13:59:00','2022-07-11 13:59:00','c17fc09c-7643-454d-9a0b-4b2472868a8f'),(52,52,1,'Contact','2022-07-11 13:59:01','2022-07-11 13:59:01','35094407-6e47-4627-be89-c410e8ac5174'),(53,53,1,'Login','2022-07-11 13:59:18','2022-07-11 13:59:18','b7dfcccf-ccee-46b6-8b10-9d72f7581d4c'),(54,54,1,'Login','2022-07-11 13:59:18','2022-07-11 13:59:18','b84b25ca-ab26-43fb-a521-c1c2ec511123'),(55,55,1,'Investment Advisory','2022-07-11 14:07:16','2022-07-11 14:07:16','12c0e590-3283-4300-93b7-e09b2479b0f5'),(56,56,1,'Start','2022-07-11 14:12:10','2022-07-11 14:12:10','6b1ca684-ed3e-4724-a508-e183cdef9ca4');
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_phmnzlpzgmatrssznldbcxdycprwplagpsnd` (`userId`),
  CONSTRAINT `fk_phmnzlpzgmatrssznldbcxdycprwplagpsnd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_etmytsafjniipsflvwfdwadaeuqmpiegvlgm` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_xelluwwrxcpfwyjwwhzqzrskxpfailpbtmmd` (`creatorId`,`provisional`),
  KEY `idx_wjbwciecbzjgjadymalzxsshqattbhrqijus` (`saved`),
  KEY `fk_fniiybvzrknxeirzgmubrnpqppkwcxocnxfw` (`canonicalId`),
  CONSTRAINT `fk_fniiybvzrknxeirzgmubrnpqppkwcxocnxfw` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jptjqqcjqcqyakmvrrbnfgakoftqzaesbfbq` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_adkpzbmqpywlfvhdhsgxvchnpfipeqeajkss` (`dateDeleted`),
  KEY `idx_zszgiddvmdnpwvmzwzbxprhyythtzfirutuc` (`fieldLayoutId`),
  KEY `idx_rixfvyqsvqcxawfhdrrigtnhywhfckxzvwwx` (`type`),
  KEY `idx_qimqkutrwoahfrjtzuygekpwjtdtwdcnptuz` (`enabled`),
  KEY `idx_uyuawdahwcnbcvakjrgumbbjqlbnduguitpy` (`archived`,`dateCreated`),
  KEY `idx_wsfxfsjyznwnijktugivocyrkmwxwujjtcbw` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_wctuqqbzicvrewvacwomssicypaotxzmekbh` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_ymzcxpefvhljnobcmcnasyfnygayrdapqbvr` (`canonicalId`),
  KEY `fk_krlnxkhpijjlowlgfoxwyobrzzcyrkkqlyck` (`draftId`),
  KEY `fk_inmqryyonysokouokfuzccxthesucdtmqfaa` (`revisionId`),
  CONSTRAINT `fk_bgqvvuymfgmpgoydixaigojmagezfdtcaueq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_inmqryyonysokouokfuzccxthesucdtmqfaa` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_krlnxkhpijjlowlgfoxwyobrzzcyrkkqlyck` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ymzcxpefvhljnobcmcnasyfnygayrdapqbvr` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2022-06-25 16:51:30','2022-06-25 16:51:30',NULL,NULL,'4833c615-76ae-472d-8afc-360f7f82a296'),(2,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2022-07-11 12:43:10','2022-07-11 14:12:10',NULL,NULL,'a8d10bd5-3421-40fe-9cef-b55f2b16989b'),(3,2,NULL,1,1,'craft\\elements\\Entry',1,0,'2022-07-11 12:43:18','2022-07-11 12:43:18',NULL,NULL,'5b606c07-9a7d-4567-903e-1e44936b409f'),(4,2,NULL,2,1,'craft\\elements\\Entry',1,0,'2022-07-11 12:46:59','2022-07-11 12:46:59',NULL,NULL,'e8e2c1a5-f1ad-411b-9632-f830aede2f28'),(5,2,NULL,3,1,'craft\\elements\\Entry',1,0,'2022-07-11 12:46:59','2022-07-11 12:46:59',NULL,NULL,'6d49c104-157a-48fd-a044-8fffae40b3b6'),(6,2,NULL,4,1,'craft\\elements\\Entry',1,0,'2022-07-11 12:46:59','2022-07-11 12:46:59',NULL,NULL,'032959cf-f72c-4b38-a959-76237c0c1855'),(7,2,NULL,5,1,'craft\\elements\\Entry',1,0,'2022-07-11 12:49:29','2022-07-11 12:49:29',NULL,NULL,'1607bf34-bc02-440c-adb9-8d350305e7cd'),(8,2,NULL,6,1,'craft\\elements\\Entry',1,0,'2022-07-11 12:49:29','2022-07-11 12:49:29',NULL,NULL,'c4b7f6cf-129a-4a60-8cae-c67f226e9eb8'),(9,2,NULL,7,1,'craft\\elements\\Entry',1,0,'2022-07-11 13:00:48','2022-07-11 13:00:48',NULL,NULL,'cba7f386-de0c-4a0a-9abd-4bc7e7601950'),(10,2,NULL,8,1,'craft\\elements\\Entry',1,0,'2022-07-11 13:00:48','2022-07-11 13:00:48',NULL,NULL,'6f0737f3-60eb-4514-824f-7d37c9d4312c'),(11,NULL,NULL,NULL,2,'craft\\elements\\Entry',1,0,'2022-07-11 13:25:41','2022-07-11 14:07:16',NULL,NULL,'a5e509a0-779e-4edc-998e-4c069adc4103'),(12,11,NULL,9,2,'craft\\elements\\Entry',1,0,'2022-07-11 13:25:41','2022-07-11 13:25:41',NULL,NULL,'af824fd0-8dda-4419-834e-c14cf8952ba2'),(13,11,NULL,10,2,'craft\\elements\\Entry',1,0,'2022-07-11 13:25:41','2022-07-11 13:25:41',NULL,NULL,'dd0f232e-7cdb-4abf-9722-514d0d530d3b'),(14,11,NULL,11,2,'craft\\elements\\Entry',1,0,'2022-07-11 13:25:41','2022-07-11 13:25:42',NULL,NULL,'4f86657a-871c-473d-ad6b-cf3cf3127c6e'),(15,11,NULL,12,2,'craft\\elements\\Entry',1,0,'2022-07-11 13:25:48','2022-07-11 13:25:48',NULL,NULL,'0131bc34-b455-4814-95da-63ee818e5ea1'),(16,11,NULL,13,2,'craft\\elements\\Entry',1,0,'2022-07-11 13:27:10','2022-07-11 13:27:10',NULL,NULL,'f0319732-a323-4329-a8d5-b2fedd4ac241'),(17,NULL,NULL,NULL,5,'craft\\elements\\Entry',1,0,'2022-07-11 13:40:11','2022-07-11 13:44:17',NULL,NULL,'4ddf869d-dc76-45ef-abe4-203044bcec60'),(18,17,NULL,14,5,'craft\\elements\\Entry',1,0,'2022-07-11 13:40:11','2022-07-11 13:40:11',NULL,NULL,'ac04d067-527d-4151-a332-324954a4f8da'),(19,17,NULL,15,5,'craft\\elements\\Entry',1,0,'2022-07-11 13:40:11','2022-07-11 13:40:11',NULL,NULL,'0e821dc3-a955-4663-9720-de0717c29f27'),(20,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2022-07-11 13:40:40','2022-07-11 13:59:01',NULL,NULL,'c376bc4f-d1d3-47aa-9c19-e97e9fa10e70'),(21,20,NULL,16,4,'craft\\elements\\Entry',1,0,'2022-07-11 13:40:40','2022-07-11 13:40:40',NULL,NULL,'4d679690-0556-478d-a474-f594693c9115'),(22,20,NULL,17,4,'craft\\elements\\Entry',1,0,'2022-07-11 13:40:40','2022-07-11 13:40:40',NULL,NULL,'874ab65c-836c-4407-b1d5-5e3737d84312'),(23,20,NULL,18,4,'craft\\elements\\Entry',1,0,'2022-07-11 13:40:40','2022-07-11 13:40:40',NULL,NULL,'1f096c83-cbfc-40d1-85c4-24da2b85449f'),(24,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2022-07-11 13:40:50','2022-07-11 13:43:44',NULL,NULL,'ac187aad-53cc-46b7-8bed-aa1970971e4f'),(25,24,NULL,19,3,'craft\\elements\\Entry',1,0,'2022-07-11 13:40:50','2022-07-11 13:40:50',NULL,NULL,'9cdd0bc9-441a-48e7-88ac-6e4d6b5e7df1'),(26,24,NULL,20,3,'craft\\elements\\Entry',1,0,'2022-07-11 13:40:50','2022-07-11 13:40:50',NULL,NULL,'2fafbc08-efb7-49cd-9b06-6708d69f2f88'),(27,24,NULL,21,3,'craft\\elements\\Entry',1,0,'2022-07-11 13:40:50','2022-07-11 13:40:51',NULL,NULL,'12697487-57a8-409a-9e8a-c5bd00837141'),(28,NULL,NULL,NULL,6,'craft\\elements\\Entry',1,0,'2022-07-11 13:41:23','2022-07-11 13:44:26',NULL,NULL,'3db0b04c-6e9b-4b32-acd1-7d5766bf583f'),(29,28,NULL,22,6,'craft\\elements\\Entry',1,0,'2022-07-11 13:41:23','2022-07-11 13:41:23',NULL,NULL,'78b6871c-1225-42a9-8c16-43da05daad96'),(30,28,NULL,23,6,'craft\\elements\\Entry',1,0,'2022-07-11 13:41:23','2022-07-11 13:41:23',NULL,NULL,'c5fc33b9-37b0-400b-bcda-ef5e2e675065'),(31,NULL,NULL,NULL,7,'craft\\elements\\Entry',1,0,'2022-07-11 13:42:31','2022-07-11 13:59:18',NULL,NULL,'03597b31-f490-4072-967e-631f8384fe34'),(32,31,NULL,24,7,'craft\\elements\\Entry',1,0,'2022-07-11 13:42:31','2022-07-11 13:42:31',NULL,NULL,'b7047ac9-6667-472a-a527-57df7cd04dc3'),(33,31,NULL,25,7,'craft\\elements\\Entry',1,0,'2022-07-11 13:42:31','2022-07-11 13:42:31',NULL,NULL,'3b82b765-8a82-4532-ae57-7e40063b265f'),(34,NULL,NULL,NULL,8,'craft\\elements\\Entry',1,0,'2022-07-11 13:43:06','2022-07-11 13:45:16',NULL,NULL,'c6a3bd17-4e3e-4588-aa74-50a38a0f041f'),(35,34,NULL,26,8,'craft\\elements\\Entry',1,0,'2022-07-11 13:43:06','2022-07-11 13:43:06',NULL,NULL,'b93a6c3d-af6e-4708-9371-96b0e8e8ba94'),(36,34,NULL,27,8,'craft\\elements\\Entry',1,0,'2022-07-11 13:43:06','2022-07-11 13:43:06',NULL,NULL,'0d637c45-5c8a-4803-a8e3-84183d5a0859'),(38,34,NULL,28,8,'craft\\elements\\Entry',1,0,'2022-07-11 13:43:36','2022-07-11 13:43:36',NULL,NULL,'469e3dc8-19e8-4eac-96f1-5c9d5f02814b'),(40,24,NULL,29,3,'craft\\elements\\Entry',1,0,'2022-07-11 13:43:44','2022-07-11 13:43:44',NULL,NULL,'6147dea1-4d37-494c-9c41-cf036a4d7b56'),(42,20,NULL,30,4,'craft\\elements\\Entry',1,0,'2022-07-11 13:44:07','2022-07-11 13:44:07',NULL,NULL,'7095ee0b-e129-4555-b49f-a21e56667f83'),(44,17,NULL,31,5,'craft\\elements\\Entry',1,0,'2022-07-11 13:44:17','2022-07-11 13:44:17',NULL,NULL,'a450e471-8070-4ad5-993d-91493adbec19'),(46,28,NULL,32,6,'craft\\elements\\Entry',1,0,'2022-07-11 13:44:26','2022-07-11 13:44:26',NULL,NULL,'ac0d033d-968e-4e5f-a6c5-e68d3f53bcc6'),(48,34,NULL,33,8,'craft\\elements\\Entry',1,0,'2022-07-11 13:45:16','2022-07-11 13:45:16',NULL,NULL,'7dff5bcd-b223-4779-9f50-371ebecadce0'),(50,11,NULL,34,2,'craft\\elements\\Entry',1,0,'2022-07-11 13:45:33','2022-07-11 13:45:33',NULL,NULL,'8e68c82d-79ba-406c-9237-23f0c6e9f80c'),(51,20,NULL,35,4,'craft\\elements\\Entry',1,0,'2022-07-11 13:59:00','2022-07-11 13:59:00',NULL,NULL,'49872605-e430-4152-a12a-67823307d325'),(52,20,NULL,36,4,'craft\\elements\\Entry',1,0,'2022-07-11 13:59:01','2022-07-11 13:59:01',NULL,NULL,'d656320e-2775-46f5-8cd5-4c4003be6fea'),(53,31,NULL,37,7,'craft\\elements\\Entry',1,0,'2022-07-11 13:59:18','2022-07-11 13:59:18',NULL,NULL,'6d766301-7d7f-463f-acda-5407c8b7f15a'),(54,31,NULL,38,7,'craft\\elements\\Entry',1,0,'2022-07-11 13:59:18','2022-07-11 13:59:18',NULL,NULL,'ba990562-4cb7-419e-bbe8-8172eae113dc'),(55,11,NULL,39,2,'craft\\elements\\Entry',1,0,'2022-07-11 14:07:16','2022-07-11 14:07:16',NULL,NULL,'a2956140-eba8-41ea-81db-a8572a2bfcd8'),(56,2,NULL,40,1,'craft\\elements\\Entry',1,0,'2022-07-11 14:12:10','2022-07-11 14:12:10',NULL,NULL,'16c28edc-1e29-407d-8d3b-9344a6c3a1dd');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ifmoyzlozjcfgxlupgabesbcjwsrslcnlqge` (`elementId`,`siteId`),
  KEY `idx_ljqhmoiejphzpznhxacvyawhwcsmkqropsuu` (`siteId`),
  KEY `idx_hxrjezjalmjxdbwgwycvxiezzejjjswwlvun` (`slug`,`siteId`),
  KEY `idx_mzhmjbqopvtmlwxdsypmiovmjekmrpltvsvh` (`enabled`),
  KEY `idx_jzockmjwskkplciymmlzoxmfpnsfgcjmhrnx` (`uri`,`siteId`),
  CONSTRAINT `fk_fghotfqvflrzszjunnrpmvdsquzxfetyxazz` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_laditxwzsyereecyprulrwifyhyyjznxlgnw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,1,'2022-06-25 16:51:30','2022-06-25 16:51:30','c2b4592e-e29a-4730-8da7-836591106eaf'),(2,2,1,'start','__home__',1,'2022-07-11 12:43:10','2022-07-11 12:46:59','18a9b103-bc2f-4911-96df-9b5d11d7ca06'),(3,3,1,'start','pages/start',1,'2022-07-11 12:43:18','2022-07-11 12:43:18','76f74e63-0611-49e3-b622-ee229d4e3929'),(4,4,1,'start','__home__',1,'2022-07-11 12:46:59','2022-07-11 12:46:59','c1ce02dd-52a9-4160-9aa4-7ea38dff4c1f'),(5,5,1,'start','__home__',1,'2022-07-11 12:46:59','2022-07-11 12:46:59','0c5584f9-a3d2-40e5-be58-904cbe2b18e0'),(6,6,1,'start','__home__',1,'2022-07-11 12:46:59','2022-07-11 12:46:59','dbdb68d9-78a1-48fa-ac99-b68e6cf3f2b5'),(7,7,1,'start','__home__',1,'2022-07-11 12:49:29','2022-07-11 12:49:29','3368daeb-84da-41b6-b89b-2645021510cd'),(8,8,1,'start','__home__',1,'2022-07-11 12:49:29','2022-07-11 12:49:29','5ee4e2fb-3e23-4a8b-b918-75846517b6d3'),(9,9,1,'start','__home__',1,'2022-07-11 13:00:48','2022-07-11 13:00:48','cb692504-9245-48f0-8c81-14a4e0bb811e'),(10,10,1,'start','__home__',1,'2022-07-11 13:00:48','2022-07-11 13:00:48','c6b52105-97b3-496a-a8a1-fdcd21a80174'),(11,11,1,'anlageberatungen','anlageberatungen',1,'2022-07-11 13:25:41','2022-07-11 13:45:33','22809d25-396c-4b24-82b3-31b5d65c30f3'),(12,12,1,'investment-advisory','investment-advisory',1,'2022-07-11 13:25:41','2022-07-11 13:25:41','627e33ff-bc62-459f-98f5-15218cdf0441'),(13,13,1,'investment-advisory','investment-advisory',1,'2022-07-11 13:25:41','2022-07-11 13:25:41','2d08dae4-205a-4f74-9969-a464eca72dbf'),(14,14,1,'investment-advisory','investment-advisory',1,'2022-07-11 13:25:42','2022-07-11 13:25:42','259acbb8-0235-4cca-9846-56258ac6ea8c'),(15,15,1,'investment-advisory','investment-advisory',1,'2022-07-11 13:25:48','2022-07-11 13:25:48','95651ab9-82ab-4e14-85ee-4a65ccdd4a06'),(16,16,1,'investment-advisory','investment-advisory',1,'2022-07-11 13:27:10','2022-07-11 13:27:10','6b30530a-b493-4255-8689-b1142e68a376'),(17,17,1,'datenschutz','datenschutz',1,'2022-07-11 13:40:11','2022-07-11 13:44:17','cc52bc22-7ed1-4af2-adc7-9952ad44ebf0'),(18,18,1,'data-privacy','data-privacy',1,'2022-07-11 13:40:11','2022-07-11 13:40:11','536f67f1-a17c-4518-9088-9f34f4659a52'),(19,19,1,'data-privacy','data-privacy',1,'2022-07-11 13:40:11','2022-07-11 13:40:11','1d212cb5-5c56-4ac7-b190-f345e36dd159'),(20,20,1,'kontakt','kontakt',1,'2022-07-11 13:40:40','2022-07-11 13:59:00','34fe684d-ee5e-4720-899d-e9d103c2c96a'),(21,21,1,'contact',NULL,1,'2022-07-11 13:40:40','2022-07-11 13:40:40','507959c0-429c-412d-975f-fdf8d8c57c1b'),(22,22,1,'contact',NULL,1,'2022-07-11 13:40:40','2022-07-11 13:40:40','8d0079ad-39d3-49ab-a168-e606cd238fb8'),(23,23,1,'contact',NULL,1,'2022-07-11 13:40:40','2022-07-11 13:40:40','2a1c183a-4716-4733-800e-4be6c27f5ccc'),(24,24,1,'ueber-uns','ueber-uns',1,'2022-07-11 13:40:50','2022-07-11 13:43:44','10acc631-9e1e-4c5a-8471-3ace7e21da9f'),(25,25,1,'about-us','about-us',1,'2022-07-11 13:40:50','2022-07-11 13:40:50','1b214848-f518-4d9c-9d9a-f07ecb426b91'),(26,26,1,'about-us','about-us',1,'2022-07-11 13:40:50','2022-07-11 13:40:50','20c74f9c-8635-4bda-9efd-c5c09f1db464'),(27,27,1,'about-us','about-us',1,'2022-07-11 13:40:51','2022-07-11 13:40:51','eec43c99-0bb0-48a1-9c06-cf89bf4c0247'),(28,28,1,'impressum','impressum',1,'2022-07-11 13:41:23','2022-07-11 13:44:26','7fd15041-0f3f-40c7-861a-82469f90d25d'),(29,29,1,'imprint','imprint',1,'2022-07-11 13:41:23','2022-07-11 13:41:23','b318567c-f4b8-4078-bb98-e6cc7936cf33'),(30,30,1,'imprint','imprint',1,'2022-07-11 13:41:23','2022-07-11 13:41:23','8819427b-4775-40b9-a9e3-78e74b5440bc'),(31,31,1,'login','login',1,'2022-07-11 13:42:31','2022-07-11 13:59:18','de00b75a-e708-4e43-93d6-b39b2fd410d7'),(32,32,1,'login',NULL,1,'2022-07-11 13:42:31','2022-07-11 13:42:31','886b20d5-9f18-43be-b7de-a1958e8ab091'),(33,33,1,'login',NULL,1,'2022-07-11 13:42:31','2022-07-11 13:42:31','fb00e229-f4e8-4e16-92a9-9099050dc9ce'),(34,34,1,'vorsorgeloesungen','vorsorgeloesungen',1,'2022-07-11 13:43:06','2022-07-11 13:45:16','3d07034a-580f-482b-9366-096a3bbc0b94'),(35,35,1,'retirement-solutions','retirement-solutions',1,'2022-07-11 13:43:06','2022-07-11 13:43:06','0a4f7dcf-f02b-4e29-869c-b8af1e869038'),(36,36,1,'retirement-solutions','retirement-solutions',1,'2022-07-11 13:43:06','2022-07-11 13:43:06','d09c75c8-5ace-4057-84ea-50bea04455d0'),(38,38,1,'anlage-beratungen','anlage-beratungen',1,'2022-07-11 13:43:36','2022-07-11 13:43:36','879a3564-ab4a-4bf0-b835-7128d5cd5053'),(40,40,1,'ueber-uns','ueber-uns',1,'2022-07-11 13:43:44','2022-07-11 13:43:44','c5a462b1-d378-41aa-8a87-f8d367a8e50e'),(42,42,1,'kontakt',NULL,1,'2022-07-11 13:44:07','2022-07-11 13:44:07','7e09169e-5b57-42ef-93b6-273f7a6291cd'),(44,44,1,'datenschutz','datenschutz',1,'2022-07-11 13:44:17','2022-07-11 13:44:17','cc3e0cb5-5d21-4f5c-8782-54436e711520'),(46,46,1,'impressum','impressum',1,'2022-07-11 13:44:26','2022-07-11 13:44:26','e887aee1-4e18-4974-a07e-34ee31cbf260'),(48,48,1,'vorsorgeloesungen','vorsorgeloesungen',1,'2022-07-11 13:45:16','2022-07-11 13:45:16','57e63691-454b-4686-b27f-022da22ae0c3'),(50,50,1,'anlageberatungen','anlageberatungen',1,'2022-07-11 13:45:33','2022-07-11 13:45:33','194952e6-3265-4573-bd50-98321d3da66a'),(51,51,1,'kontakt','kontakt',1,'2022-07-11 13:59:00','2022-07-11 13:59:00','71676766-ea79-429e-a220-3bda1ead8d32'),(52,52,1,'kontakt','kontakt',1,'2022-07-11 13:59:01','2022-07-11 13:59:01','94647890-291c-4251-815e-c1a96b57f070'),(53,53,1,'login','login',1,'2022-07-11 13:59:18','2022-07-11 13:59:18','6a9f6c60-465a-4918-a5a4-4a46b8caea48'),(54,54,1,'login','login',1,'2022-07-11 13:59:18','2022-07-11 13:59:18','5d91fe58-a126-4209-ba61-28603b25c7a6'),(55,55,1,'anlageberatungen','anlageberatungen',1,'2022-07-11 14:07:16','2022-07-11 14:07:16','cef5e612-f09b-4e5c-88e7-3c95382cd05f'),(56,56,1,'start','__home__',1,'2022-07-11 14:12:10','2022-07-11 14:12:10','cb0323cb-9537-4241-b87d-7c3652085a54');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `authorId` int DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ljefpmfmyscyvfrrgptvvukxlqrkahbdiosb` (`postDate`),
  KEY `idx_pygfwxknjffrpfeudxdyxuptgkhdysfdozpc` (`expiryDate`),
  KEY `idx_sbrseirsvhvyqpvlullqejpythcwimvqjljy` (`authorId`),
  KEY `idx_blvebsjsxtplcbboffkwzkymseobondzyshq` (`sectionId`),
  KEY `idx_mxoguilycdomzpidxwkwhxkcfzxpswqcatna` (`typeId`),
  KEY `fk_kfenntcmgdxrfpmcnmflznoltrzzyxvcwaay` (`parentId`),
  CONSTRAINT `fk_bhswumbxdnybbigdjcihkqkfceqkiydizaup` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kfenntcmgdxrfpmcnmflznoltrzzyxvcwaay` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_nrejqjcgookkvaspdvrctzvsdpwtrqphhofi` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rakzbdqccdxfcglzhjzsciitexmhfufstwlv` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uimjvtfuiffcaeampqarlvmchkuhptrtmvty` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,1,NULL,1,NULL,'2022-07-11 12:43:00',NULL,NULL,'2022-07-11 12:43:10','2022-07-11 12:46:59'),(3,1,NULL,1,1,'2022-07-11 12:43:00',NULL,NULL,'2022-07-11 12:43:18','2022-07-11 12:43:18'),(4,1,NULL,1,NULL,'2022-07-11 12:43:00',NULL,NULL,'2022-07-11 12:46:59','2022-07-11 12:46:59'),(5,1,NULL,1,NULL,'2022-07-11 12:43:00',NULL,NULL,'2022-07-11 12:46:59','2022-07-11 12:46:59'),(6,1,NULL,1,NULL,'2022-07-11 12:43:00',NULL,NULL,'2022-07-11 12:46:59','2022-07-11 12:46:59'),(7,1,NULL,1,NULL,'2022-07-11 12:43:00',NULL,NULL,'2022-07-11 12:49:29','2022-07-11 12:49:29'),(8,1,NULL,1,NULL,'2022-07-11 12:43:00',NULL,NULL,'2022-07-11 12:49:29','2022-07-11 12:49:29'),(9,1,NULL,1,NULL,'2022-07-11 12:43:00',NULL,NULL,'2022-07-11 13:00:48','2022-07-11 13:00:48'),(10,1,NULL,1,NULL,'2022-07-11 12:43:00',NULL,NULL,'2022-07-11 13:00:48','2022-07-11 13:00:48'),(11,2,NULL,2,NULL,'2022-07-11 13:25:00',NULL,NULL,'2022-07-11 13:25:41','2022-07-11 13:25:41'),(12,2,NULL,2,NULL,'2022-07-11 13:25:00',NULL,NULL,'2022-07-11 13:25:41','2022-07-11 13:25:41'),(13,2,NULL,2,NULL,'2022-07-11 13:25:00',NULL,NULL,'2022-07-11 13:25:41','2022-07-11 13:25:41'),(14,2,NULL,2,NULL,'2022-07-11 13:25:00',NULL,NULL,'2022-07-11 13:25:42','2022-07-11 13:25:42'),(15,2,NULL,2,NULL,'2022-07-11 13:25:00',NULL,NULL,'2022-07-11 13:25:48','2022-07-11 13:25:48'),(16,2,NULL,2,NULL,'2022-07-11 13:25:00',NULL,NULL,'2022-07-11 13:27:10','2022-07-11 13:27:10'),(17,5,NULL,5,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:40:11','2022-07-11 13:40:11'),(18,5,NULL,5,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:40:11','2022-07-11 13:40:11'),(19,5,NULL,5,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:40:11','2022-07-11 13:40:11'),(20,4,NULL,4,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:40:40','2022-07-11 13:40:40'),(21,4,NULL,4,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:40:40','2022-07-11 13:40:40'),(22,4,NULL,4,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:40:40','2022-07-11 13:40:40'),(23,4,NULL,4,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:40:40','2022-07-11 13:40:40'),(24,3,NULL,3,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:40:50','2022-07-11 13:40:50'),(25,3,NULL,3,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:40:50','2022-07-11 13:40:50'),(26,3,NULL,3,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:40:50','2022-07-11 13:40:50'),(27,3,NULL,3,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:40:51','2022-07-11 13:40:51'),(28,6,NULL,6,NULL,'2022-07-11 13:41:00',NULL,NULL,'2022-07-11 13:41:23','2022-07-11 13:41:23'),(29,6,NULL,6,NULL,'2022-07-11 13:41:00',NULL,NULL,'2022-07-11 13:41:23','2022-07-11 13:41:23'),(30,6,NULL,6,NULL,'2022-07-11 13:41:00',NULL,NULL,'2022-07-11 13:41:23','2022-07-11 13:41:23'),(31,7,NULL,7,NULL,'2022-07-11 13:42:00',NULL,NULL,'2022-07-11 13:42:31','2022-07-11 13:42:31'),(32,7,NULL,7,NULL,'2022-07-11 13:42:00',NULL,NULL,'2022-07-11 13:42:31','2022-07-11 13:42:31'),(33,7,NULL,7,NULL,'2022-07-11 13:42:00',NULL,NULL,'2022-07-11 13:42:31','2022-07-11 13:42:31'),(34,8,NULL,8,NULL,'2022-07-11 13:43:00',NULL,NULL,'2022-07-11 13:43:06','2022-07-11 13:43:06'),(35,8,NULL,8,NULL,'2022-07-11 13:43:00',NULL,NULL,'2022-07-11 13:43:06','2022-07-11 13:43:06'),(36,8,NULL,8,NULL,'2022-07-11 13:43:00',NULL,NULL,'2022-07-11 13:43:06','2022-07-11 13:43:06'),(38,8,NULL,8,NULL,'2022-07-11 13:43:00',NULL,NULL,'2022-07-11 13:43:36','2022-07-11 13:43:36'),(40,3,NULL,3,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:43:44','2022-07-11 13:43:44'),(42,4,NULL,4,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:44:07','2022-07-11 13:44:07'),(44,5,NULL,5,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:44:17','2022-07-11 13:44:17'),(46,6,NULL,6,NULL,'2022-07-11 13:41:00',NULL,NULL,'2022-07-11 13:44:26','2022-07-11 13:44:26'),(48,8,NULL,8,NULL,'2022-07-11 13:43:00',NULL,NULL,'2022-07-11 13:45:16','2022-07-11 13:45:16'),(50,2,NULL,2,NULL,'2022-07-11 13:25:00',NULL,NULL,'2022-07-11 13:45:33','2022-07-11 13:45:33'),(51,4,NULL,4,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:59:00','2022-07-11 13:59:00'),(52,4,NULL,4,NULL,'2022-07-11 13:40:00',NULL,NULL,'2022-07-11 13:59:01','2022-07-11 13:59:01'),(53,7,NULL,7,NULL,'2022-07-11 13:42:00',NULL,NULL,'2022-07-11 13:59:18','2022-07-11 13:59:18'),(54,7,NULL,7,NULL,'2022-07-11 13:42:00',NULL,NULL,'2022-07-11 13:59:18','2022-07-11 13:59:18'),(55,2,NULL,2,NULL,'2022-07-11 13:25:00',NULL,NULL,'2022-07-11 14:07:16','2022-07-11 14:07:16'),(56,1,NULL,1,NULL,'2022-07-11 12:43:00',NULL,NULL,'2022-07-11 14:12:10','2022-07-11 14:12:10');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tivjbkazfzkdehjzxppbocpckuljebjbywcc` (`name`,`sectionId`),
  KEY `idx_spmhgffjkbvklbmblzwunaxadzekuzhyghql` (`handle`,`sectionId`),
  KEY `idx_ybflbzkuxubyhjkuljkfmwvwtsmwidpgrjyc` (`sectionId`),
  KEY `idx_hcaccctznzkwszikgjoicezifwjtqdcyrfet` (`fieldLayoutId`),
  KEY `idx_txzlobutunwqhjhpzorrdwaerssjwglykgxz` (`dateDeleted`),
  CONSTRAINT `fk_jzeeuroccvzwenugmuukfsqoeaqxeweeavir` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yjyaikkuxmeigfalugbsuwiirwdrjtetxvbn` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,1,1,'Start','start',1,'site',NULL,NULL,1,'2022-07-11 12:41:22','2022-07-11 12:46:59',NULL,'465ad94a-6ff0-4776-aec3-1a8d9c28d177'),(2,2,2,'Investment Advisory','invesmentAdvisory',1,'site',NULL,NULL,1,'2022-07-11 13:24:55','2022-07-11 13:25:41',NULL,'8d9fb8fc-aa34-42cb-98bc-97228160016c'),(3,3,3,'About Us','aboutUs',1,'site',NULL,NULL,1,'2022-07-11 13:39:07','2022-07-11 13:40:50',NULL,'567b3a46-9655-43df-8e0d-02a52454e459'),(4,4,4,'Contact','contact',1,'site',NULL,NULL,1,'2022-07-11 13:39:35','2022-07-11 13:40:40',NULL,'a8a54faf-f815-4b38-80ee-c66acca0a063'),(5,5,5,'Data Privacy','dataPrivacy',0,'site',NULL,'{section.name|raw}',1,'2022-07-11 13:40:11','2022-07-11 13:40:11',NULL,'47e94b3a-30ca-480e-aade-3be1b448c694'),(6,6,6,'Imprint','imprint',0,'site',NULL,'{section.name|raw}',1,'2022-07-11 13:41:23','2022-07-11 13:41:23',NULL,'bdc004e6-236b-4444-a1c9-8e8cfbdcc67c'),(7,7,7,'Login','login',0,'site',NULL,'{section.name|raw}',1,'2022-07-11 13:42:31','2022-07-11 13:42:31',NULL,'505b5f6b-5951-4484-9ced-7f3f61abc5d9'),(8,8,8,'Retirement Solutions','retirementSolutions',0,'site',NULL,'{section.name|raw}',1,'2022-07-11 13:43:06','2022-07-11 13:43:06',NULL,'5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e'),(9,9,NULL,'Default','default',1,'site',NULL,NULL,1,'2022-07-11 14:21:43','2022-07-11 14:23:00',NULL,'a81b2519-de8d-404a-bff8-bcc3402ad870');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldgroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ojnhunvvcvcohsftejvotavdurfuktxevlha` (`name`),
  KEY `idx_ycqatpucvpnuxwniyapqldgtllyftefmcsiw` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
INSERT INTO `fieldgroups` VALUES (1,'Common','2022-06-25 16:51:30','2022-06-25 16:51:30',NULL,'0e8b9745-1a76-4aa6-b2f1-f72225252c2c'),(2,'Services','2022-07-11 14:24:01','2022-07-11 14:24:01',NULL,'2335bc14-e769-484f-9f4f-9dc2f14e9db3');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `tabId` int NOT NULL,
  `fieldId` int NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ttwkvoomgttmwlpzzsidwbpvikmrvvldpukr` (`layoutId`,`fieldId`),
  KEY `idx_mtdadjdqhypkbfthmxrhpbwclyaeiirhbixn` (`sortOrder`),
  KEY `idx_jvwlhywmkwnmnoeavycydkdcfkwpxllfczok` (`tabId`),
  KEY `idx_iziprzjepglfamfvlsxsrhoneguijjvftknd` (`fieldId`),
  CONSTRAINT `fk_aqjoukluazimjgfdgikepxlflswtlhzzicom` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ngztobivpezbclpcgcmszynnxcawaybdvdhs` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vgscachykuanoszdyohxymuxpoczqtovibgi` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rgxghduldrnyighewglqzijknfnbpkxnpsxf` (`dateDeleted`),
  KEY `idx_nmjodmatpghllananlgxdhrysmzodqhlnksq` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','2022-07-11 12:41:22','2022-07-11 12:41:22',NULL,'4bc60b16-7d28-41d7-bca2-8d41ce98de1e'),(2,'craft\\elements\\Entry','2022-07-11 13:24:55','2022-07-11 13:24:55',NULL,'13971a86-ba0a-4c56-a2c6-35505dc88558'),(3,'craft\\elements\\Entry','2022-07-11 13:39:07','2022-07-11 13:39:07',NULL,'9db3d397-08f0-4aeb-8747-e96a7a2b9a7d'),(4,'craft\\elements\\Entry','2022-07-11 13:39:35','2022-07-11 13:39:35',NULL,'958c5407-77aa-41b9-98a8-610a80df893c'),(5,'craft\\elements\\Entry','2022-07-11 13:40:11','2022-07-11 13:40:11',NULL,'17cc3486-9bf3-43cb-a76c-53e44329528e'),(6,'craft\\elements\\Entry','2022-07-11 13:41:23','2022-07-11 13:41:23',NULL,'823ca4af-4b0d-467a-843c-aec36a2d9ab4'),(7,'craft\\elements\\Entry','2022-07-11 13:42:31','2022-07-11 13:42:31',NULL,'dbcc6db4-57d8-46b7-a9b7-af6b960a5979'),(8,'craft\\elements\\Entry','2022-07-11 13:43:06','2022-07-11 13:43:06',NULL,'e88ad07d-b69f-453b-87bf-0694be07783e'),(9,'craft\\elements\\Entry','2022-07-11 14:21:43','2022-07-11 14:21:43','2022-07-11 14:23:00','78d78722-a554-438a-8489-1146f269409a');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `layoutId` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text,
  `elements` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ddmxyfacnpdhhzoiupqoujpdpchuzbuuywzl` (`sortOrder`),
  KEY `idx_trzbmrjvkhgfvyljbiequydhudhmnikbthug` (`layoutId`),
  CONSTRAINT `fk_xxfdxiidqiwqosurqfzpeweilifvvbfkdtse` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
INSERT INTO `fieldlayouttabs` VALUES (2,1,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"ea078790-27f3-4efc-8522-43a55be7f8e4\"}]',1,'2022-07-11 12:46:59','2022-07-11 12:46:59','bdbba0a6-6e14-49aa-9d75-30959483a9a8'),(4,2,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"19d60be7-079a-4ffc-b168-93afdb8abb72\"}]',1,'2022-07-11 13:25:41','2022-07-11 13:25:41','a0e41219-97d9-4074-8962-33c80bfd16f1'),(7,5,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"7fda213f-2987-40cf-9b80-b58d6bdf3897\"}]',1,'2022-07-11 13:40:11','2022-07-11 13:40:11','54520c51-3799-4a0e-9705-2c84a0d4b541'),(8,4,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"8f22a18e-8e66-4c28-8f8d-74eaa6ac0b39\"}]',1,'2022-07-11 13:40:40','2022-07-11 13:40:40','0bd97a08-34a3-4bd5-98ba-e5b67803a279'),(9,3,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"fc71a9bd-c2ca-4026-bec7-e91ac7d0c96b\"}]',1,'2022-07-11 13:40:50','2022-07-11 13:40:50','defa5ab6-258a-483a-8b57-a839b86289af'),(10,6,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"49abdf51-9016-4f9f-9be4-827727ddfa7a\"}]',1,'2022-07-11 13:41:23','2022-07-11 13:41:23','c33c29a7-6366-4c7d-bed2-3093c8463ce1'),(11,7,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"07d089c6-b319-425e-ab2c-02846b89ec8d\"}]',1,'2022-07-11 13:42:31','2022-07-11 13:42:31','962a2a2b-a617-4001-84dd-e5deaaab163e'),(12,8,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"55e50ec9-395b-4b43-9c64-5354f7570daf\"}]',1,'2022-07-11 13:43:06','2022-07-11 13:43:06','d44bd344-8c52-449b-8ecc-4d8eef5151da'),(13,9,'Content','[]','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"2740e1ee-9879-46f5-a083-8a8a9b629537\"}]',1,'2022-07-11 14:21:43','2022-07-11 14:21:43','55bd48e1-fc56-4bab-8506-f4a0685e8838');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_blbypcowqppxztiqotdetyqbneuhqkxbywen` (`handle`,`context`),
  KEY `idx_ksouylnylutgtwjslqhtxtwcnupmkpixrdlc` (`groupId`),
  KEY `idx_obameqqocehrfaylirhtbxaxfdukpknvpsbk` (`context`),
  CONSTRAINT `fk_gefekoxmogyqsrggjzfiltyflyasyyftojod` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qtyuaqrnwglltumcfmigrggfrgfxowbmhjhu` (`name`),
  KEY `idx_howlrpyydnxyjytonjxtemgywqwzhcbhfwxu` (`handle`),
  KEY `idx_eolfoxgxtbbnjxqbzkiilgzyjiwvgbolzooy` (`fieldLayoutId`),
  KEY `idx_nklbshdhicqmxbbgmwhjqltyhkycxjzcrdxt` (`sortOrder`),
  CONSTRAINT `fk_alrxrhlovbgvyjbpiksirftzhagzqcstrvjt` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ymyiymkistlsilcelpabdhfqpywohjurvmxd` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_phwajcungnqxaefqkevfsygnzjgtklokvuxj` (`accessToken`),
  UNIQUE KEY `idx_iqaeqnwnlsvlmofppeuuupemplamzyihrfjd` (`name`),
  KEY `fk_udesvdovbxjcrnyphkrmzhvxlgbixvahdmde` (`schemaId`),
  CONSTRAINT `fk_udesvdovbxjcrnyphkrmzhvxlgbixvahdmde` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xeuqbhrkxiujisrynrlmwjxqygfhewmodbfq` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_raiiheqjlousmqybottunohwlcrazetkqyta` (`name`),
  KEY `idx_afbhurfcbmofkzxgsxwflqmnahcnbgwhklgf` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'4.0.5.2','4.0.0.9',0,'bwrdmwwqbpxx','3@vnviamqunl','2022-06-25 16:51:30','2022-07-11 14:24:01','51bed747-d607-4aa9-84b6-6ecef900b484');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks` (
  `id` int NOT NULL,
  `primaryOwnerId` int NOT NULL,
  `fieldId` int NOT NULL,
  `typeId` int NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_lxzwablykxwjvhlkyggsotmvqlxacyintpwj` (`primaryOwnerId`),
  KEY `idx_luczmrgketojtkkpmauqbvigoknfktstdlyp` (`fieldId`),
  KEY `idx_ruyjayywnxrmlbdfbvnbytffjopanlxgwzug` (`typeId`),
  CONSTRAINT `fk_adjhqgjbpemcydcmqbfxqxauhhnpegqpugnx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gacatrnhoxhpuxshlqcqwypwhqivagenvjlt` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_izwvvngepjnuclnljyaqqlrenjjdtvjvqdsf` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tzwpvrrcmtcwgckhoxzjrxlpkucbztanrhmv` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_khfrmjrzhixsngcqhijfftttyjgsjzrarbhn` (`ownerId`),
  CONSTRAINT `fk_khfrmjrzhixsngcqhijfftttyjgsjzrarbhn` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lbszilhtkudkpxdegaptjyqsnlnkeasuxmcz` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matrixblocktypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qeyxpbjaoyxlafhvjmxkqhpzpajqofwpaunj` (`name`,`fieldId`),
  KEY `idx_oxvfgmhaedfqtecgyhiiyjvistzoicgneqkt` (`handle`,`fieldId`),
  KEY `idx_wvnxdvlckjapdhxsmmjmrmmvmcjohehbexvi` (`fieldId`),
  KEY `idx_kjmxjuazrvnmrlhhgndxyteozlllepbfkxyh` (`fieldLayoutId`),
  CONSTRAINT `fk_ejtximgqziwcuggfbcgniiksikjrqpcoakzq` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jsmzrurvoefagvgdntagqoipuabgqnydarpg` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kqhppdtnkgknefwffejcxqqckgbsvvomlnvd` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'craft','Install','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','5aceb217-7316-42b9-adfc-abc7ac94191c'),(2,'craft','m210121_145800_asset_indexing_changes','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','da1ead47-0c87-4e2f-bd07-3efab8cd4c1c'),(3,'craft','m210624_222934_drop_deprecated_tables','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','ad877f23-4df7-4bcc-b9f8-3d0c346b272b'),(4,'craft','m210724_180756_rename_source_cols','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','eae115eb-3191-432e-a826-34db4f70a5d7'),(5,'craft','m210809_124211_remove_superfluous_uids','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','7c4a2cea-eac2-41b9-b993-b06564313080'),(6,'craft','m210817_014201_universal_users','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','f8fd9d1b-a4f5-4377-9ae0-db83c4c66dd5'),(7,'craft','m210904_132612_store_element_source_settings_in_project_config','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','871c6f40-5bce-469b-971d-c60cf81c6c87'),(8,'craft','m211115_135500_image_transformers','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','330449ae-b76e-426c-82ef-12597649e36b'),(9,'craft','m211201_131000_filesystems','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','1a392250-3fc9-4829-92f5-06f194366df0'),(10,'craft','m220103_043103_tab_conditions','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','8641da1f-5077-440b-8feb-f247eeb0a15e'),(11,'craft','m220104_003433_asset_alt_text','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','9cec4ce2-61e8-4ca2-81fb-fd27f5ed9d06'),(12,'craft','m220123_213619_update_permissions','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','1fa45ce6-be8f-464f-bf74-1743dc8156ac'),(13,'craft','m220126_003432_addresses','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','d7769639-fc71-4fc7-bb12-014fd77a662b'),(14,'craft','m220209_095604_add_indexes','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','16ab488f-d3e2-4d1c-944a-2182e9b18a41'),(15,'craft','m220213_015220_matrixblocks_owners_table','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','50a4d1c8-258c-4eb1-ad5d-6109ceaa6203'),(16,'craft','m220214_000000_truncate_sessions','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','e3db1493-2b50-42ab-aebc-4d3c338ffb01'),(17,'craft','m220222_122159_full_names','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','6efb610d-d860-46ce-925e-6539823c79fb'),(18,'craft','m220223_180559_nullable_address_owner','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','4e412b3a-ba9e-407c-a910-ab503cf79e07'),(19,'craft','m220225_165000_transform_filesystems','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','8090ae04-6833-44c8-9092-080242427e06'),(20,'craft','m220309_152006_rename_field_layout_elements','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','1f26da24-58ce-4f20-9793-924e13dd1a48'),(21,'craft','m220314_211928_field_layout_element_uids','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','86a34ce9-6b28-4135-9f4f-0b6b5d9b89a7'),(22,'craft','m220316_123800_transform_fs_subpath','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','443e4dff-b7a9-4940-b30d-0254935b111c'),(23,'craft','m220317_174250_release_all_jobs','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','d81eb5a7-5711-4a6a-ade8-48e0d46c02ba'),(24,'craft','m220330_150000_add_site_gql_schema_components','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','acc130ed-abf8-47d1-a69e-47ae177fd1fd'),(25,'craft','m220413_024536_site_enabled_string','2022-06-25 16:51:31','2022-06-25 16:51:31','2022-06-25 16:51:31','b9b95203-a5bf-42e9-9b0b-d3df9326fad8');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKeyStatus` enum('valid','trial','invalid','mismatched','astray','unknown') NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ccvzqdznkneuqbtlazjukabnefzgztghstfw` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('dateModified','1657549441'),('elementSources.craft\\elements\\Entry.0.disabled','false'),('elementSources.craft\\elements\\Entry.0.key','\"*\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.0','\"section\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.1','\"postDate\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.2','\"expiryDate\"'),('elementSources.craft\\elements\\Entry.0.tableAttributes.3','\"link\"'),('elementSources.craft\\elements\\Entry.0.type','\"native\"'),('elementSources.craft\\elements\\Entry.1.disabled','false'),('elementSources.craft\\elements\\Entry.1.key','\"singles\"'),('elementSources.craft\\elements\\Entry.1.tableAttributes.0','\"link\"'),('elementSources.craft\\elements\\Entry.1.tableAttributes.1','\"slug\"'),('elementSources.craft\\elements\\Entry.1.type','\"native\"'),('elementSources.craft\\elements\\Entry.2.heading','\"Navigation\"'),('elementSources.craft\\elements\\Entry.2.type','\"heading\"'),('email.fromEmail','\"tools@haaswebsolutions.io\"'),('email.fromName','\"kr-consulting\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.autocapitalize','true'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.autocomplete','false'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.autocorrect','true'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.class','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.disabled','false'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.id','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.instructions','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.label','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.max','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.min','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.name','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.orientation','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.placeholder','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.readonly','false'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.requirable','false'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.size','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.step','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.tip','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.title','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.uid','\"ea078790-27f3-4efc-8522-43a55be7f8e4\"'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.warning','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.elements.0.width','100'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.name','\"Content\"'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.fieldLayouts.4bc60b16-7d28-41d7-bca2-8d41ce98de1e.tabs.0.uid','\"bdbba0a6-6e14-49aa-9d75-30959483a9a8\"'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.handle','\"start\"'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.hasTitleField','true'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.name','\"Start\"'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.section','\"1603d4ed-dff5-40eb-8f99-db85545a375e\"'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.sortOrder','1'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.titleFormat','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.titleTranslationKeyFormat','null'),('entryTypes.465ad94a-6ff0-4776-aec3-1a8d9c28d177.titleTranslationMethod','\"site\"'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.autocapitalize','true'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.autocomplete','false'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.autocorrect','true'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.class','null'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.disabled','false'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.id','null'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.instructions','null'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.label','null'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.max','null'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.min','null'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.name','null'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.orientation','null'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.placeholder','null'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.readonly','false'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.requirable','false'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.size','null'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.step','null'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.tip','null'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.title','null'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.uid','\"7fda213f-2987-40cf-9b80-b58d6bdf3897\"'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.warning','null'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.elements.0.width','100'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.name','\"Content\"'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.fieldLayouts.17cc3486-9bf3-43cb-a76c-53e44329528e.tabs.0.uid','\"54520c51-3799-4a0e-9705-2c84a0d4b541\"'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.handle','\"dataPrivacy\"'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.hasTitleField','false'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.name','\"Data Privacy\"'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.section','\"cf05b8dd-8dfa-47ae-a86d-e19e315bd668\"'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.sortOrder','1'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.titleFormat','\"{section.name|raw}\"'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.titleTranslationKeyFormat','null'),('entryTypes.47e94b3a-30ca-480e-aade-3be1b448c694.titleTranslationMethod','\"site\"'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.autocapitalize','true'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.autocomplete','false'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.autocorrect','true'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.class','null'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.disabled','false'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.id','null'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.instructions','null'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.label','null'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.max','null'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.min','null'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.name','null'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.orientation','null'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.placeholder','null'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.readonly','false'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.requirable','false'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.size','null'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.step','null'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.tip','null'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.title','null'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.uid','\"07d089c6-b319-425e-ab2c-02846b89ec8d\"'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.warning','null'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.elements.0.width','100'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.name','\"Content\"'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.fieldLayouts.dbcc6db4-57d8-46b7-a9b7-af6b960a5979.tabs.0.uid','\"962a2a2b-a617-4001-84dd-e5deaaab163e\"'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.handle','\"login\"'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.hasTitleField','false'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.name','\"Login\"'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.section','\"c157b61b-db87-471f-8609-c7f60ecf7283\"'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.sortOrder','1'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.titleFormat','\"{section.name|raw}\"'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.titleTranslationKeyFormat','null'),('entryTypes.505b5f6b-5951-4484-9ced-7f3f61abc5d9.titleTranslationMethod','\"site\"'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.autocapitalize','true'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.autocomplete','false'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.autocorrect','true'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.class','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.disabled','false'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.id','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.instructions','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.label','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.max','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.min','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.name','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.orientation','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.placeholder','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.readonly','false'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.requirable','false'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.size','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.step','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.tip','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.title','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.uid','\"fc71a9bd-c2ca-4026-bec7-e91ac7d0c96b\"'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.warning','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.elements.0.width','100'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.name','\"Content\"'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.fieldLayouts.9db3d397-08f0-4aeb-8747-e96a7a2b9a7d.tabs.0.uid','\"defa5ab6-258a-483a-8b57-a839b86289af\"'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.handle','\"aboutUs\"'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.hasTitleField','true'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.name','\"About Us\"'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.section','\"1e53762a-6675-426a-9783-3793bdd16929\"'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.sortOrder','1'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.titleFormat','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.titleTranslationKeyFormat','null'),('entryTypes.567b3a46-9655-43df-8e0d-02a52454e459.titleTranslationMethod','\"site\"'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.autocapitalize','true'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.autocomplete','false'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.autocorrect','true'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.class','null'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.disabled','false'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.id','null'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.instructions','null'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.label','null'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.max','null'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.min','null'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.name','null'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.orientation','null'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.placeholder','null'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.readonly','false'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.requirable','false'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.size','null'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.step','null'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.tip','null'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.title','null'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.uid','\"55e50ec9-395b-4b43-9c64-5354f7570daf\"'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.warning','null'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.elements.0.width','100'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.name','\"Content\"'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.fieldLayouts.e88ad07d-b69f-453b-87bf-0694be07783e.tabs.0.uid','\"d44bd344-8c52-449b-8ecc-4d8eef5151da\"'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.handle','\"retirementSolutions\"'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.hasTitleField','false'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.name','\"Retirement Solutions\"'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.section','\"9f90e5bc-9157-4526-8dde-681edb929c58\"'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.sortOrder','1'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.titleFormat','\"{section.name|raw}\"'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.titleTranslationKeyFormat','null'),('entryTypes.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e.titleTranslationMethod','\"site\"'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.autocapitalize','true'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.autocomplete','false'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.autocorrect','true'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.class','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.disabled','false'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.id','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.instructions','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.label','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.max','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.min','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.name','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.orientation','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.placeholder','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.readonly','false'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.requirable','false'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.size','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.step','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.tip','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.title','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.uid','\"19d60be7-079a-4ffc-b168-93afdb8abb72\"'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.warning','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.elements.0.width','100'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.name','\"Content\"'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.fieldLayouts.13971a86-ba0a-4c56-a2c6-35505dc88558.tabs.0.uid','\"a0e41219-97d9-4074-8962-33c80bfd16f1\"'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.handle','\"invesmentAdvisory\"'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.hasTitleField','true'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.name','\"Investment Advisory\"'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.section','\"f9dc201a-1d70-41de-addd-45fd5fafb195\"'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.sortOrder','1'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.titleFormat','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.titleTranslationKeyFormat','null'),('entryTypes.8d9fb8fc-aa34-42cb-98bc-97228160016c.titleTranslationMethod','\"site\"'),('entryTypes.a81b2519-de8d-404a-bff8-bcc3402ad870.handle','\"default\"'),('entryTypes.a81b2519-de8d-404a-bff8-bcc3402ad870.hasTitleField','true'),('entryTypes.a81b2519-de8d-404a-bff8-bcc3402ad870.name','\"Default\"'),('entryTypes.a81b2519-de8d-404a-bff8-bcc3402ad870.section','\"6ef04a00-5ae7-4cb6-a2b7-1d1ad0acf651\"'),('entryTypes.a81b2519-de8d-404a-bff8-bcc3402ad870.sortOrder','1'),('entryTypes.a81b2519-de8d-404a-bff8-bcc3402ad870.titleFormat','null'),('entryTypes.a81b2519-de8d-404a-bff8-bcc3402ad870.titleTranslationKeyFormat','null'),('entryTypes.a81b2519-de8d-404a-bff8-bcc3402ad870.titleTranslationMethod','\"site\"'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.autocapitalize','true'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.autocomplete','false'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.autocorrect','true'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.class','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.disabled','false'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.id','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.instructions','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.label','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.max','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.min','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.name','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.orientation','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.placeholder','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.readonly','false'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.requirable','false'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.size','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.step','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.tip','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.title','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.uid','\"8f22a18e-8e66-4c28-8f8d-74eaa6ac0b39\"'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.warning','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.elements.0.width','100'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.name','\"Content\"'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.fieldLayouts.958c5407-77aa-41b9-98a8-610a80df893c.tabs.0.uid','\"0bd97a08-34a3-4bd5-98ba-e5b67803a279\"'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.handle','\"contact\"'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.hasTitleField','true'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.name','\"Contact\"'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.section','\"abb7c8e9-a3e2-4c0d-a2f4-23606f8a06e2\"'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.sortOrder','1'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.titleFormat','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.titleTranslationKeyFormat','null'),('entryTypes.a8a54faf-f815-4b38-80ee-c66acca0a063.titleTranslationMethod','\"site\"'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.autocapitalize','true'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.autocomplete','false'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.autocorrect','true'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.class','null'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.disabled','false'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.id','null'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.instructions','null'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.label','null'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.max','null'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.min','null'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.name','null'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.orientation','null'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.placeholder','null'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.readonly','false'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.requirable','false'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.size','null'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.step','null'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.tip','null'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.title','null'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.uid','\"49abdf51-9016-4f9f-9be4-827727ddfa7a\"'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.warning','null'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.elements.0.width','100'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.name','\"Content\"'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.fieldLayouts.823ca4af-4b0d-467a-843c-aec36a2d9ab4.tabs.0.uid','\"c33c29a7-6366-4c7d-bed2-3093c8463ce1\"'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.handle','\"imprint\"'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.hasTitleField','false'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.name','\"Imprint\"'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.section','\"5ebc446b-1d16-47b3-890a-35c338268fa6\"'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.sortOrder','1'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.titleFormat','\"{section.name|raw}\"'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.titleTranslationKeyFormat','null'),('entryTypes.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c.titleTranslationMethod','\"site\"'),('fieldGroups.0e8b9745-1a76-4aa6-b2f1-f72225252c2c.name','\"Common\"'),('fieldGroups.2335bc14-e769-484f-9f4f-9dc2f14e9db3.name','\"Services\"'),('meta.__names__.0e8b9745-1a76-4aa6-b2f1-f72225252c2c','\"Common\"'),('meta.__names__.1603d4ed-dff5-40eb-8f99-db85545a375e','\"Start\"'),('meta.__names__.1e53762a-6675-426a-9783-3793bdd16929','\"About Us\"'),('meta.__names__.2335bc14-e769-484f-9f4f-9dc2f14e9db3','\"Services\"'),('meta.__names__.465ad94a-6ff0-4776-aec3-1a8d9c28d177','\"Start\"'),('meta.__names__.47e94b3a-30ca-480e-aade-3be1b448c694','\"Data Privacy\"'),('meta.__names__.505b5f6b-5951-4484-9ced-7f3f61abc5d9','\"Login\"'),('meta.__names__.567b3a46-9655-43df-8e0d-02a52454e459','\"About Us\"'),('meta.__names__.5797b8b9-3f5f-4ea9-8bd6-80f9e56e761e','\"Retirement Solutions\"'),('meta.__names__.5ebc446b-1d16-47b3-890a-35c338268fa6','\"Imprint\"'),('meta.__names__.6ef04a00-5ae7-4cb6-a2b7-1d1ad0acf651','\"Services\"'),('meta.__names__.8d9fb8fc-aa34-42cb-98bc-97228160016c','\"Investment Advisory\"'),('meta.__names__.9f90e5bc-9157-4526-8dde-681edb929c58','\"Retirement Solutions\"'),('meta.__names__.a81b2519-de8d-404a-bff8-bcc3402ad870','\"Default\"'),('meta.__names__.a8a54faf-f815-4b38-80ee-c66acca0a063','\"Contact\"'),('meta.__names__.abb7c8e9-a3e2-4c0d-a2f4-23606f8a06e2','\"Contact\"'),('meta.__names__.ac664f09-a9af-40d3-a60f-889403d18d91','\"kr-consulting\"'),('meta.__names__.ba58fc37-be30-4b99-a88d-7f4d9e94e73d','\"kr-consulting\"'),('meta.__names__.bdc004e6-236b-4444-a1c9-8e8cfbdcc67c','\"Imprint\"'),('meta.__names__.c157b61b-db87-471f-8609-c7f60ecf7283','\"Login\"'),('meta.__names__.cf05b8dd-8dfa-47ae-a86d-e19e315bd668','\"Data Privacy\"'),('meta.__names__.f9dc201a-1d70-41de-addd-45fd5fafb195','\"Investment Advisory\"'),('sections.1603d4ed-dff5-40eb-8f99-db85545a375e.defaultPlacement','\"end\"'),('sections.1603d4ed-dff5-40eb-8f99-db85545a375e.enableVersioning','true'),('sections.1603d4ed-dff5-40eb-8f99-db85545a375e.handle','\"start\"'),('sections.1603d4ed-dff5-40eb-8f99-db85545a375e.name','\"Start\"'),('sections.1603d4ed-dff5-40eb-8f99-db85545a375e.propagationMethod','\"all\"'),('sections.1603d4ed-dff5-40eb-8f99-db85545a375e.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.enabledByDefault','true'),('sections.1603d4ed-dff5-40eb-8f99-db85545a375e.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.hasUrls','true'),('sections.1603d4ed-dff5-40eb-8f99-db85545a375e.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.template','\"05_pages/start.twig\"'),('sections.1603d4ed-dff5-40eb-8f99-db85545a375e.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.uriFormat','\"__home__\"'),('sections.1603d4ed-dff5-40eb-8f99-db85545a375e.type','\"single\"'),('sections.1e53762a-6675-426a-9783-3793bdd16929.defaultPlacement','\"end\"'),('sections.1e53762a-6675-426a-9783-3793bdd16929.enableVersioning','true'),('sections.1e53762a-6675-426a-9783-3793bdd16929.handle','\"aboutUs\"'),('sections.1e53762a-6675-426a-9783-3793bdd16929.name','\"About Us\"'),('sections.1e53762a-6675-426a-9783-3793bdd16929.propagationMethod','\"all\"'),('sections.1e53762a-6675-426a-9783-3793bdd16929.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.enabledByDefault','true'),('sections.1e53762a-6675-426a-9783-3793bdd16929.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.hasUrls','true'),('sections.1e53762a-6675-426a-9783-3793bdd16929.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.template','\"05_pages/about-us.twig\"'),('sections.1e53762a-6675-426a-9783-3793bdd16929.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.uriFormat','\"{slug}\"'),('sections.1e53762a-6675-426a-9783-3793bdd16929.type','\"single\"'),('sections.5ebc446b-1d16-47b3-890a-35c338268fa6.defaultPlacement','\"end\"'),('sections.5ebc446b-1d16-47b3-890a-35c338268fa6.enableVersioning','true'),('sections.5ebc446b-1d16-47b3-890a-35c338268fa6.handle','\"imprint\"'),('sections.5ebc446b-1d16-47b3-890a-35c338268fa6.name','\"Imprint\"'),('sections.5ebc446b-1d16-47b3-890a-35c338268fa6.propagationMethod','\"all\"'),('sections.5ebc446b-1d16-47b3-890a-35c338268fa6.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.enabledByDefault','true'),('sections.5ebc446b-1d16-47b3-890a-35c338268fa6.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.hasUrls','true'),('sections.5ebc446b-1d16-47b3-890a-35c338268fa6.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.template','\"05_pages/imprint.twig\"'),('sections.5ebc446b-1d16-47b3-890a-35c338268fa6.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.uriFormat','\"{slug}\"'),('sections.5ebc446b-1d16-47b3-890a-35c338268fa6.type','\"single\"'),('sections.6ef04a00-5ae7-4cb6-a2b7-1d1ad0acf651.defaultPlacement','\"end\"'),('sections.6ef04a00-5ae7-4cb6-a2b7-1d1ad0acf651.enableVersioning','true'),('sections.6ef04a00-5ae7-4cb6-a2b7-1d1ad0acf651.handle','\"services\"'),('sections.6ef04a00-5ae7-4cb6-a2b7-1d1ad0acf651.name','\"Services\"'),('sections.6ef04a00-5ae7-4cb6-a2b7-1d1ad0acf651.propagationMethod','\"all\"'),('sections.6ef04a00-5ae7-4cb6-a2b7-1d1ad0acf651.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.enabledByDefault','true'),('sections.6ef04a00-5ae7-4cb6-a2b7-1d1ad0acf651.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.hasUrls','false'),('sections.6ef04a00-5ae7-4cb6-a2b7-1d1ad0acf651.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.template','null'),('sections.6ef04a00-5ae7-4cb6-a2b7-1d1ad0acf651.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.uriFormat','null'),('sections.6ef04a00-5ae7-4cb6-a2b7-1d1ad0acf651.type','\"channel\"'),('sections.9f90e5bc-9157-4526-8dde-681edb929c58.defaultPlacement','\"end\"'),('sections.9f90e5bc-9157-4526-8dde-681edb929c58.enableVersioning','true'),('sections.9f90e5bc-9157-4526-8dde-681edb929c58.handle','\"retirementSolutions\"'),('sections.9f90e5bc-9157-4526-8dde-681edb929c58.name','\"Retirement Solutions\"'),('sections.9f90e5bc-9157-4526-8dde-681edb929c58.propagationMethod','\"all\"'),('sections.9f90e5bc-9157-4526-8dde-681edb929c58.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.enabledByDefault','true'),('sections.9f90e5bc-9157-4526-8dde-681edb929c58.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.hasUrls','true'),('sections.9f90e5bc-9157-4526-8dde-681edb929c58.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.template','\"05_pages/retirement-solutions.twig\"'),('sections.9f90e5bc-9157-4526-8dde-681edb929c58.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.uriFormat','\"{slug}\"'),('sections.9f90e5bc-9157-4526-8dde-681edb929c58.type','\"single\"'),('sections.abb7c8e9-a3e2-4c0d-a2f4-23606f8a06e2.defaultPlacement','\"end\"'),('sections.abb7c8e9-a3e2-4c0d-a2f4-23606f8a06e2.enableVersioning','true'),('sections.abb7c8e9-a3e2-4c0d-a2f4-23606f8a06e2.handle','\"contact\"'),('sections.abb7c8e9-a3e2-4c0d-a2f4-23606f8a06e2.name','\"Contact\"'),('sections.abb7c8e9-a3e2-4c0d-a2f4-23606f8a06e2.propagationMethod','\"all\"'),('sections.abb7c8e9-a3e2-4c0d-a2f4-23606f8a06e2.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.enabledByDefault','true'),('sections.abb7c8e9-a3e2-4c0d-a2f4-23606f8a06e2.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.hasUrls','true'),('sections.abb7c8e9-a3e2-4c0d-a2f4-23606f8a06e2.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.template','\"05_pages/contact.twig\"'),('sections.abb7c8e9-a3e2-4c0d-a2f4-23606f8a06e2.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.uriFormat','\"{slug}\"'),('sections.abb7c8e9-a3e2-4c0d-a2f4-23606f8a06e2.type','\"single\"'),('sections.c157b61b-db87-471f-8609-c7f60ecf7283.defaultPlacement','\"end\"'),('sections.c157b61b-db87-471f-8609-c7f60ecf7283.enableVersioning','true'),('sections.c157b61b-db87-471f-8609-c7f60ecf7283.handle','\"login\"'),('sections.c157b61b-db87-471f-8609-c7f60ecf7283.name','\"Login\"'),('sections.c157b61b-db87-471f-8609-c7f60ecf7283.propagationMethod','\"all\"'),('sections.c157b61b-db87-471f-8609-c7f60ecf7283.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.enabledByDefault','true'),('sections.c157b61b-db87-471f-8609-c7f60ecf7283.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.hasUrls','true'),('sections.c157b61b-db87-471f-8609-c7f60ecf7283.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.template','\"05_pages/login.twig\"'),('sections.c157b61b-db87-471f-8609-c7f60ecf7283.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.uriFormat','\"{slug}\"'),('sections.c157b61b-db87-471f-8609-c7f60ecf7283.type','\"single\"'),('sections.cf05b8dd-8dfa-47ae-a86d-e19e315bd668.defaultPlacement','\"end\"'),('sections.cf05b8dd-8dfa-47ae-a86d-e19e315bd668.enableVersioning','true'),('sections.cf05b8dd-8dfa-47ae-a86d-e19e315bd668.handle','\"dataPrivacy\"'),('sections.cf05b8dd-8dfa-47ae-a86d-e19e315bd668.name','\"Data Privacy\"'),('sections.cf05b8dd-8dfa-47ae-a86d-e19e315bd668.propagationMethod','\"all\"'),('sections.cf05b8dd-8dfa-47ae-a86d-e19e315bd668.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.enabledByDefault','true'),('sections.cf05b8dd-8dfa-47ae-a86d-e19e315bd668.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.hasUrls','true'),('sections.cf05b8dd-8dfa-47ae-a86d-e19e315bd668.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.template','\"05_pages/data-privacy.twig\"'),('sections.cf05b8dd-8dfa-47ae-a86d-e19e315bd668.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.uriFormat','\"{slug}\"'),('sections.cf05b8dd-8dfa-47ae-a86d-e19e315bd668.type','\"single\"'),('sections.f9dc201a-1d70-41de-addd-45fd5fafb195.defaultPlacement','\"end\"'),('sections.f9dc201a-1d70-41de-addd-45fd5fafb195.enableVersioning','true'),('sections.f9dc201a-1d70-41de-addd-45fd5fafb195.handle','\"invesmentAdvisory\"'),('sections.f9dc201a-1d70-41de-addd-45fd5fafb195.name','\"Investment Advisory\"'),('sections.f9dc201a-1d70-41de-addd-45fd5fafb195.propagationMethod','\"all\"'),('sections.f9dc201a-1d70-41de-addd-45fd5fafb195.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.enabledByDefault','true'),('sections.f9dc201a-1d70-41de-addd-45fd5fafb195.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.hasUrls','true'),('sections.f9dc201a-1d70-41de-addd-45fd5fafb195.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.template','\"05_pages/investment-advisory.twig\"'),('sections.f9dc201a-1d70-41de-addd-45fd5fafb195.siteSettings.ac664f09-a9af-40d3-a60f-889403d18d91.uriFormat','\"{slug}\"'),('sections.f9dc201a-1d70-41de-addd-45fd5fafb195.type','\"single\"'),('siteGroups.ba58fc37-be30-4b99-a88d-7f4d9e94e73d.name','\"kr-consulting\"'),('sites.ac664f09-a9af-40d3-a60f-889403d18d91.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.ac664f09-a9af-40d3-a60f-889403d18d91.enabled','true'),('sites.ac664f09-a9af-40d3-a60f-889403d18d91.handle','\"default\"'),('sites.ac664f09-a9af-40d3-a60f-889403d18d91.hasUrls','true'),('sites.ac664f09-a9af-40d3-a60f-889403d18d91.language','\"de-CH\"'),('sites.ac664f09-a9af-40d3-a60f-889403d18d91.name','\"kr-consulting\"'),('sites.ac664f09-a9af-40d3-a60f-889403d18d91.primary','true'),('sites.ac664f09-a9af-40d3-a60f-889403d18d91.siteGroup','\"ba58fc37-be30-4b99-a88d-7f4d9e94e73d\"'),('sites.ac664f09-a9af-40d3-a60f-889403d18d91.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"kr-consulting\"'),('system.schemaVersion','\"4.0.0.9\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_yjwzkowulgoiqsqxczgaibkkijoohalodsnb` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_hhemurrhnzqhfmazklpaqrsydexkqqxeixrb` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_eaidiminyzergebeclargmozkljadklyggbn` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_ywstslqylcerotyigvzffdlokigtyrweyudj` (`sourceId`),
  KEY `idx_cjwmnfrbmdywrqttbwsscdksiziygkuwekvi` (`targetId`),
  KEY `idx_xoqpenfqpidtfrvxeluznfarysihptckyzwm` (`sourceSiteId`),
  CONSTRAINT `fk_bhafzkgqzjxfpifmfvwpcfmqlbddfzjbhjqj` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qlrftrghuxoyvydrralrtzhqzkfdxaqmjooj` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rzhwpjucnzxwdpszxpfnupcplpxsycqqlsjz` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vdjaifeuxeqiiculbnhpubwjrnxpyfjkzsja` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('1245492b','@craft/web/assets/htmx/dist'),('23eccbf9','@bower/jquery/dist'),('260cd411','@craft/web/assets/elementresizedetector/dist'),('290b5bef','@craft/web/assets/jqueryui/dist'),('37708d44','@craft/web/assets/fileupload/dist'),('3cf8ae2d','@craft/web/assets/prismjs/dist'),('40c5d02b','@craft/web/assets/craftsupport/dist'),('42a107ef','@craft/web/assets/xregexp/dist'),('4919baef','@craft/web/assets/picturefill/dist'),('64ad4a82','@craft/web/assets/editsection/dist'),('64f5badd','@craft/web/assets/vue/dist'),('693cba4','@craft/web/assets/dashboard/dist'),('70d56286','@craft/web/assets/velocity/dist'),('7511bf53','@craft/web/assets/jquerytouchevents/dist'),('75426031','@craft/web/assets/jquerypayment/dist'),('7fd0ed6f','@craft/web/assets/feed/dist'),('9f7d6650','@craft/web/assets/garnish/dist'),('a7e5c779','@craft/web/assets/utilities/dist'),('b7cf5147','@craft/web/assets/fabric/dist'),('b93d555a','@craft/web/assets/sites/dist'),('c126f115','@craft/web/assets/axios/dist'),('d0102213','@craft/web/assets/updater/dist'),('d9d3644c','@craft/web/assets/recententries/dist'),('da540c18','@craft/web/assets/conditionbuilder/dist'),('e722d9fa','@craft/web/assets/d3/dist'),('e7692622','@craft/web/assets/updateswidget/dist'),('ea2a057b','@craft/web/assets/fieldsettings/dist'),('ec43d04d','@craft/web/assets/iframeresizer/dist'),('f15f5dfb','@craft/web/assets/selectize/dist'),('f46ccfce','@craft/web/assets/pluginstore/dist'),('f64ae7d9','@craft/web/assets/tailwindreset/dist'),('fd17ffb3','@craft/web/assets/cp/dist'),('ffec4c28','@craft/web/assets/focusvisible/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dhusfnauehimsdokgkqujspxqrddvzcynqjv` (`canonicalId`,`num`),
  KEY `fk_zbculnqaoilspzfjodjzcefqpfkxtiebvouf` (`creatorId`),
  CONSTRAINT `fk_gigsmsfjepjnqjkwmhondtxaguaitlvmsrmn` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zbculnqaoilspzfjodjzcefqpfkxtiebvouf` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,2,1,1,''),(2,2,1,2,NULL),(3,2,1,3,NULL),(4,2,1,4,NULL),(5,2,1,5,NULL),(6,2,1,6,NULL),(7,2,1,7,NULL),(8,2,1,8,NULL),(9,11,1,1,NULL),(10,11,1,2,NULL),(11,11,1,3,NULL),(12,11,1,4,NULL),(13,11,1,5,NULL),(14,17,1,1,NULL),(15,17,1,2,NULL),(16,20,1,1,NULL),(17,20,1,2,NULL),(18,20,1,3,NULL),(19,24,1,1,NULL),(20,24,1,2,NULL),(21,24,1,3,NULL),(22,28,1,1,NULL),(23,28,1,2,NULL),(24,31,1,1,NULL),(25,31,1,2,NULL),(26,34,1,1,NULL),(27,34,1,2,NULL),(28,34,1,3,'Applied “Draft 1”'),(29,24,1,4,'Applied “Draft 1”'),(30,20,1,4,'Applied “Draft 1”'),(31,17,1,3,'Applied “Draft 1”'),(32,28,1,3,'Applied “Draft 1”'),(33,34,1,4,'Applied “Draft 1”'),(34,11,1,6,'Applied “Draft 1”'),(35,20,1,5,NULL),(36,20,1,6,NULL),(37,31,1,3,NULL),(38,31,1,4,NULL),(39,11,1,7,NULL),(40,2,1,9,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_jefqiqrtlbzqtszscrifywysbowmoqdtnamk` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'username',0,1,' admin '),(1,'fullname',0,1,''),(1,'firstname',0,1,''),(1,'lastname',0,1,''),(1,'email',0,1,' tools haaswebsolutions io '),(1,'slug',0,1,''),(11,'slug',0,1,' anlageberatungen '),(2,'title',0,1,' start '),(2,'slug',0,1,' start '),(11,'title',0,1,' investment advisory '),(17,'slug',0,1,' datenschutz '),(20,'title',0,1,' contact '),(17,'title',0,1,' data privacy '),(20,'slug',0,1,' kontakt '),(24,'title',0,1,' about us '),(24,'slug',0,1,' ueber uns '),(28,'slug',0,1,' impressum '),(31,'title',0,1,' login '),(34,'title',0,1,' retirement solutions '),(34,'slug',0,1,' vorsorgeloesungen '),(28,'title',0,1,' imprint '),(31,'slug',0,1,' login ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pelcbbvurxzawlwwnehksitujapiuglxsejb` (`handle`),
  KEY `idx_jihxjnqdczgwxyjrtbokecwbofspitcdqhmi` (`name`),
  KEY `idx_caijuadyrzmahycuanxiurptalebgbmptcfh` (`structureId`),
  KEY `idx_itxxzgucyjxsiunmdwvotwvotiqeiqynycap` (`dateDeleted`),
  CONSTRAINT `fk_nanxbdqwtsrjlwiudjfcssetxybdqbhzjfhi` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Start','start','single',1,'all','end',NULL,'2022-07-11 12:41:22','2022-07-11 12:46:59',NULL,'1603d4ed-dff5-40eb-8f99-db85545a375e'),(2,NULL,'Investment Advisory','invesmentAdvisory','single',1,'all','end',NULL,'2022-07-11 13:24:55','2022-07-11 13:25:41',NULL,'f9dc201a-1d70-41de-addd-45fd5fafb195'),(3,NULL,'About Us','aboutUs','single',1,'all','end',NULL,'2022-07-11 13:39:07','2022-07-11 13:40:50',NULL,'1e53762a-6675-426a-9783-3793bdd16929'),(4,NULL,'Contact','contact','single',1,'all','end',NULL,'2022-07-11 13:39:35','2022-07-11 13:40:40',NULL,'abb7c8e9-a3e2-4c0d-a2f4-23606f8a06e2'),(5,NULL,'Data Privacy','dataPrivacy','single',1,'all','end',NULL,'2022-07-11 13:40:11','2022-07-11 13:40:11',NULL,'cf05b8dd-8dfa-47ae-a86d-e19e315bd668'),(6,NULL,'Imprint','imprint','single',1,'all','end',NULL,'2022-07-11 13:41:23','2022-07-11 13:41:23',NULL,'5ebc446b-1d16-47b3-890a-35c338268fa6'),(7,NULL,'Login','login','single',1,'all','end',NULL,'2022-07-11 13:42:31','2022-07-11 13:42:31',NULL,'c157b61b-db87-471f-8609-c7f60ecf7283'),(8,NULL,'Retirement Solutions','retirementSolutions','single',1,'all','end',NULL,'2022-07-11 13:43:06','2022-07-11 13:43:06',NULL,'9f90e5bc-9157-4526-8dde-681edb929c58'),(9,NULL,'Services','services','channel',1,'all','end',NULL,'2022-07-11 14:21:43','2022-07-11 14:21:43',NULL,'6ef04a00-5ae7-4cb6-a2b7-1d1ad0acf651');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_fqalfofknszokbzcapdehvosglospewstycw` (`sectionId`,`siteId`),
  KEY `idx_ibasckcnjqgcygycfiusgfzfpwpikllriire` (`siteId`),
  CONSTRAINT `fk_eggfeqmicizkqilsussvbajqmgthhuudbwyu` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rawpnqgrfegvzduvccnkhogtksajougbfkxr` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__','05_pages/start.twig',1,'2022-07-11 12:41:22','2022-07-11 13:00:48','242e4fb6-30b7-47fb-915e-cbb6e3a19de2'),(2,2,1,1,'{slug}','05_pages/investment-advisory.twig',1,'2022-07-11 13:24:55','2022-07-11 13:25:41','fe5760fb-b38e-448a-8027-a3c69ded3856'),(3,3,1,1,'{slug}','05_pages/about-us.twig',1,'2022-07-11 13:39:07','2022-07-11 13:39:07','d229e1fa-ba61-41b6-abcf-2bf74b399807'),(4,4,1,1,'{slug}','05_pages/contact.twig',1,'2022-07-11 13:39:35','2022-07-11 13:59:00','7733902f-2798-43fe-ad1c-34d5a63d8239'),(5,5,1,1,'{slug}','05_pages/data-privacy.twig',1,'2022-07-11 13:40:11','2022-07-11 13:40:11','2f5448db-3692-46b0-811a-bec08db0b18a'),(6,6,1,1,'{slug}','05_pages/imprint.twig',1,'2022-07-11 13:41:23','2022-07-11 13:41:23','f47570f2-32c9-40ef-b6ed-a91f5b311d23'),(7,7,1,1,'{slug}','05_pages/login.twig',1,'2022-07-11 13:42:31','2022-07-11 13:59:18','f81c1dfd-be69-4d2a-a578-061303e6495b'),(8,8,1,1,'{slug}','05_pages/retirement-solutions.twig',1,'2022-07-11 13:43:06','2022-07-11 13:43:06','3c26b28e-acff-4adc-91be-66660a5b42e3'),(9,9,1,0,NULL,NULL,1,'2022-07-11 14:21:43','2022-07-11 14:21:43','db65e810-eefe-44aa-a9cd-e8948bedbd40');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ycysrvorjhavxsczjkkzzcedoioqrfummqku` (`uid`),
  KEY `idx_fjpdfkvaebmvmusuhdkyuxjemlbsubqhlpud` (`token`),
  KEY `idx_cckhanksrpjzjwynewwdehsfovelaliffrgn` (`dateUpdated`),
  KEY `idx_kxinwnkoqfuxozorcyhtktmszujcplnzeyzk` (`userId`),
  CONSTRAINT `fk_ygxhrciduzfduekkdlpkkktuizwwwtcyrhtj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'jKg_MpwIoa9Q68VLenKg4fxN593XYQoryKLrfy1lnVfGSl4ahqbTrSbYQfT880iGHA7KkGVQgyTKemvr9Fqljpbnk82MiBUKb1rS','2022-06-25 16:51:31','2022-06-25 16:57:35','f744c13b-dc0a-4fd3-ae2a-1cf13a9bc5e1');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tmecimsrmvyxzhymhkbdnplotcvezkruoqpp` (`userId`,`message`),
  CONSTRAINT `fk_cqttfzwdazqecuvpfhgvbvxyhlxpuckowjmo` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_usugodgbitsbnkcomlxssfqwoludzldnllgn` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'kr-consulting','2022-06-25 16:51:30','2022-06-25 16:51:30',NULL,'ba58fc37-be30-4b99-a88d-7f4d9e94e73d');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_rpyazztaihaoxpajjgvomcyqwcvamhbfdwia` (`dateDeleted`),
  KEY `idx_kamqhsbkdvcqemubgaisiontzkgdkimdfdus` (`handle`),
  KEY `idx_stsgiemgsdzmgobfmujlmadqxwhkotkhzcig` (`sortOrder`),
  KEY `fk_noqlmdapzgupztojovayhfgaxbrujhoosxra` (`groupId`),
  CONSTRAINT `fk_noqlmdapzgupztojovayhfgaxbrujhoosxra` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'1','kr-consulting','default','de-CH',1,'$PRIMARY_SITE_URL',1,'2022-06-25 16:51:30','2022-07-11 12:30:08',NULL,'ac664f09-a9af-40d3-a60f-889403d18d91');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kjlzyjykqcnrmfshvjwsbivoamghqvuxbamu` (`structureId`,`elementId`),
  KEY `idx_drnnsxfzhdseabpjmjoegcwlmhvugnmgbfqe` (`root`),
  KEY `idx_zsojwulajxgtlnpyjzsvnimbkiouapsbkcwq` (`lft`),
  KEY `idx_feowwtbzlhaywyozmjjcbdxswyuuhalrvvks` (`rgt`),
  KEY `idx_qsjivleopmevindqprjpiwpapyofalmtdioh` (`level`),
  KEY `idx_vtcjhluvxxuiinkceflozfihohxmjwcvqqwu` (`elementId`),
  CONSTRAINT `fk_jltzidbihqygzvllqgyzcqxmlsddlizpgkss` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uirqmfqxslzymzrrimyyyexudcwitpgqucvr` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ckbldpxqhdvgwubuaczwcrkoiwcnksaursks` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_unauzkhpksuhrcvmdvutlvuosyfozeqwthja` (`key`,`language`),
  KEY `idx_cvknksylpcnfvfmvdzjvtkdsebhdtiuklcap` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_btzslaynavfpnulouksqgrnvgocwzxbywngh` (`name`),
  KEY `idx_xprtitmhytarvkrcyzhfijwtpjlcjkzslisr` (`handle`),
  KEY `idx_qicnkjmigjrpvivklvsbqnjwjhlgikluqffj` (`dateDeleted`),
  KEY `fk_tsxcysvmpctfcndfesechqjqduqtxyvuacep` (`fieldLayoutId`),
  CONSTRAINT `fk_tsxcysvmpctfcndfesechqjqduqtxyvuacep` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jxlcezvrlxnrnxxpqaxfjtmgxejhdvevdzld` (`groupId`),
  CONSTRAINT `fk_qsxeishvmpqeirgzrowvxdahqyocmtfejzih` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rkmowkizlvkfwzwjkigaocxgkssaogkrygmp` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_blvbzwuevmnojabvkgotvkpnzxynysygivre` (`token`),
  KEY `idx_hrscspdckpvzmgaesibuooxxwkhqqccwylwi` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mdnkuvxgkjwgrrvwolythbfhbvyzxyidurrm` (`handle`),
  KEY `idx_gyvudvvexvdrbbcmowvuhvzfmmwnmtdhkcpp` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wqpuwptswtstsqefpjgbtrtbzatbekofixai` (`groupId`,`userId`),
  KEY `idx_bdkourhkoswygqggavhxatxdbzgbbbtruakc` (`userId`),
  CONSTRAINT `fk_cunqijumtrpmehdxcyzhvimcbtfecsgkunwz` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rkprljdwkmkydzwwefycqtuvdrabpjzvncbx` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tkbffetqsnlnhvzdohpqxpovgaycnonrihlu` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rewvjrdiqwnkvprtxugqybicxkhduguudjyb` (`permissionId`,`groupId`),
  KEY `idx_wcqqxxpmemvwgthvjpefgqoemosliogiftrd` (`groupId`),
  CONSTRAINT `fk_jnovfeytntxymkixdvckaodvajpqzsqsyozm` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_onelrpmbbhldwvgwckclizyosxagiukhwgng` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_jweareudmrjosqkaijrqdowmfigazhpkwvnb` (`permissionId`,`userId`),
  KEY `idx_ddhmnkkdrdowbeeuimrfgpwtuhkjvjlpofck` (`userId`),
  CONSTRAINT `fk_hohkckdtytnlduhujiyhhqauwxkxaqeerrie` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ndisniopvlsjhtkbespzrczmhzmqdgyrudoo` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` text,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_zrpamgwpbrlkkchevqoyyjwbjksrxyoleqhi` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\":\"en\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gowysrftwcaegpxvtdukqhnqpjxhksbxrghr` (`active`),
  KEY `idx_hpdisoalzmycpvyeqseuehqzdoksvranxrox` (`locked`),
  KEY `idx_kbqpcxkydhuwtxbbttdnekcgkrjeajqvziko` (`pending`),
  KEY `idx_vrgbvqrcyjjvgcoelldmhfsibvlqljigqpiv` (`suspended`),
  KEY `idx_jhcpadhkgrxhkuecgodnonxoaozuiwmywbtd` (`verificationCode`),
  KEY `idx_njvdkttbnwukkohkhqhxswqkhqkbamktpqca` (`email`),
  KEY `idx_jeobuegvoqcbqnjbxyglerpiahslwzsnvppz` (`username`),
  KEY `fk_klbfpwcrugukgmdqhusnhjyysszqxwbpgbxl` (`photoId`),
  CONSTRAINT `fk_klbfpwcrugukgmdqhusnhjyysszqxwbpgbxl` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_leozssajofmmkgoezcgskuqnvueapcyjvgpx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'admin',NULL,NULL,NULL,'tools@haaswebsolutions.io','$2y$13$MGcX4sVr.e9Go0QoOEploePv9Ae.sz1pUVvVaBlH4A9QJUeY4t/x2','2022-07-11 12:29:13',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2022-06-25 16:51:31','2022-06-25 16:51:31','2022-07-11 12:29:13');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nhfhhzqjubpnypvvoalqblutwoodprzsheid` (`name`,`parentId`,`volumeId`),
  KEY `idx_xnltqoiwckewvlyyfexgytysjkpyftcygmmu` (`parentId`),
  KEY `idx_zqgyrozllkecsdkvcqmddmvlfnpxmelcsqiq` (`volumeId`),
  CONSTRAINT `fk_cipgtqlelubslgidnqpxpltroiwbssncshnx` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rdxxieafrrbgjmxnygrgrzvgegcdikcexjqz` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dacpqeupgeeeoeizmxconpfptxgwtlkdfmpc` (`name`),
  KEY `idx_tijhoaykbcnaejsjgtguloqykaygidelzsub` (`handle`),
  KEY `idx_aqtwfgkdnconfxriondhsifxvwcprcdhlkmf` (`fieldLayoutId`),
  KEY `idx_uyxwznjdcsqkrfadrhizrtnowbbpypgkjmmn` (`dateDeleted`),
  CONSTRAINT `fk_qnwfuennvakhrmbedogymdnuvyhpncixuvby` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` text,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bxslrwbvtoqookylmqkvfdrfjqiprrsyanon` (`userId`),
  CONSTRAINT `fk_julgcnxjshjjhpuzddcljsszjcpevopzgqss` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2022-06-25 16:51:32','2022-06-25 16:51:32','80f11752-0eb9-4f8d-9596-85e57627f023'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2022-06-25 16:51:32','2022-06-25 16:51:32','b0c38142-5652-4b52-a3b3-1bb8f5cd27e4'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2022-06-25 16:51:32','2022-06-25 16:51:32','62967e71-e496-4df8-b105-7398cc90a999'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2022-06-25 16:51:32','2022-06-25 16:51:32','2bef523f-29c7-49c0-91a2-a8f841e388ca');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-11 20:55:50
